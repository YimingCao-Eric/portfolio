import os
from typing import Union, Tuple

import cv2
import torch
import asyncio
from pathlib import Path
from tqdm.asyncio import tqdm
from skimage.io import imread_collection, imsave
from torchvision.transforms.functional import resize
from torchvision.transforms import InterpolationMode

from python.utils import get_all_images_in_directory, imreadRGB, imwriteRGB


async def main(
        #  Input image directory and extension.
        input_dir="real_img",
        input_ext="TIF",
        # Resized image directory.
        resized_dir="resized_img",
        # resized_image_shape = int(resize_factor * input_image_shape)
        resize_factor=0.2,
        # Interpolation mode: 'nearest', 'bilinear', 'bicubic'.
        # Speed: 'nearest' > 'bilinear' > 'bicubic'.
        # Quality: 'nearest' < 'bilinear' < 'bicubic'.
        interpolation_mode="bilinear",
        # Anti-aliasing improves the quality of resized image. It is enabled by default in torchvision.
        anti_alias=True,
):
    device = torch.device("cuda" if torch.cuda.is_available()
                          else "mps" if torch.backends.mps.is_available()
    else "cpu")
    print(f"torch use {device}")
    if not os.path.exists(resized_dir):
        os.makedirs(resized_dir)

    inputs = imread_collection(os.path.join(input_dir, "*." + input_ext), conserve_memory=True)
    input_paths = str(inputs)[1:-1].translate({ord("'"): None}).split(", ")
    input_names = map(lambda e: Path(e).stem, input_paths)

    try:
        main_iterator = tqdm(zip(inputs, input_names), total=len(inputs), position=0)
        main_iterator.set_description("Resized")
        async for input, input_name in main_iterator:
            """
            Input image: target(H,W,3).
            """
            input = torch.tensor(input, dtype=torch.uint8, device=device)
            input_filename = input_name + "." + input_ext

            """
            Resized image: pred(H,W,3).
            """
            resized = None
            H, W = int(input.size(0) * resize_factor), int(input.size(1) * resize_factor)
            match interpolation_mode:
                case "nearest":
                    resized = resize(
                        input.unsqueeze(0).transpose(0, 3).squeeze(3),
                        [H, W],
                        interpolation=InterpolationMode.NEAREST,
                        antialias=anti_alias).unsqueeze(3).transpose(0, 3).squeeze(0)
                case "bilinear":
                    resized = resize(
                        input.unsqueeze(0).transpose(0, 3).squeeze(3),
                        [H, W],
                        interpolation=InterpolationMode.BILINEAR,
                        antialias=anti_alias).unsqueeze(3).transpose(0, 3).squeeze(0)
                case "bicubic":
                    resized = resize(
                        input.unsqueeze(0).transpose(0, 3).squeeze(3),
                        [H, W],
                        interpolation=InterpolationMode.BICUBIC,
                        antialias=anti_alias).unsqueeze(3).transpose(0, 3).squeeze(0)
                case _:
                    print(f"\nInvalid interpolation mode {interpolation_mode}. Expected 'nearest', 'bilinear', 'bicubic'.")

            del input, H, W

            """
            Save resized image.
            """
            imsave(
                os.path.join(resized_dir, "resized_" + str(resize_factor) + "_" + interpolation_mode + "_" + input_filename),
                resized.cpu().detach().numpy(),
                plugin="tifffile",
                check_contrast=False)

    except Exception:
        print(f"\nError found in dataset around {os.path.join(input_dir, input_filename)}.")
        raise


def resize_all_imgs_in_directory(
        source_directory_path: Union[str, bytes, os.PathLike],
        output_directory_path: Union[str, bytes, os.PathLike],
        target_size: Tuple[int, int],
        mode: int = cv2.INTER_LINEAR
):
    # Resize all the images in a folder to target size, with resizing mode, and store it into the output_directory_path.
    img_infos = get_all_images_in_directory(source_directory_path)
    for img_filename, img_path in tqdm(img_infos, total=len(img_infos)):
        img = imreadRGB(img_path)
        resized_img = cv2.resize(img, target_size, interpolation=mode)
        imwriteRGB(os.path.join(output_directory_path, img_filename), resized_img)


def resize_all_imgs_in_directory_by_factors(
        source_directory_path: Union[str, bytes, os.PathLike],
        output_directory_path: Union[str, bytes, os.PathLike],
        fx: float,
        fy: float,
        mode: int = cv2.INTER_LINEAR
):
    # Resize all the images in a folder by multiplying resizing factors to each dimension, with resizing mode, and store it into the output_directory_path.
    img_infos = get_all_images_in_directory(source_directory_path)
    for img_filename, img_path in tqdm(img_infos, total=len(img_infos)):
        img = imreadRGB(img_path)
        resized_img = cv2.resize(img, fx=fx, fy=fy, dsize=None, interpolation=mode)
        imwriteRGB(os.path.join(output_directory_path, img_filename), resized_img)


def change_height_width_all_imgs_in_directory(
        source_directory_path: Union[str, bytes, os.PathLike],
        output_directory_path: Union[str, bytes, os.PathLike],
        mode: int = cv2.INTER_LINEAR
):
    # Resize all the images in a folder by flipping the width and height, with resizing mode, and store it into the output_directory_path.
    img_infos = get_all_images_in_directory(source_directory_path)
    for img_filename, img_path in tqdm(img_infos, total=len(img_infos)):
        img = imreadRGB(img_path)
        target_size = (img.shape[0], img.shape[1])
        resized_img = cv2.resize(img, target_size, interpolation=mode)
        imwriteRGB(os.path.join(output_directory_path, img_filename), resized_img)


if __name__ == "__main__":
    original_img_dir = "E:\\EECE541_dataset\\original_images\\RAISE1000_dataset"
    resize_config = [
        (0.25, 0.25, "E:\\EECE541_dataset\\resized_025_raise1000_imgs"),
        (0.50, 0.50, "E:\\EECE541_dataset\\resized_050_raise1000_imgs"),
        (2.00, 2.00, "E:\\EECE541_dataset\\resized_200_raise1000_imgs"),
    ]
    for fx, fy, output_dir in resize_config:
        print(
            f"Doing resizing with the following configuration: fx:{fx}, fy:{fy}, original image directory: {original_img_dir}, output image directory: {output_dir}")
        resize_all_imgs_in_directory_by_factors(source_directory_path=original_img_dir, output_directory_path=output_dir, fx=fx, fy=fy)
