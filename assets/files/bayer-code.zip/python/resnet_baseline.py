import os
import numpy as np
import torchvision
from PIL import Image
from sklearn.metrics import accuracy_score, recall_score, precision_score, f1_score
from torchvision import datasets, transforms, models
import torch
from torch.utils.data import DataLoader, Subset, Dataset
from torch import nn, optim
from sklearn.model_selection import train_test_split
from tqdm import tqdm


class SingleClassImageFolder(Dataset):
    def list_images(self):
        image_extensions = {'.jpg', '.jpeg', '.png', '.tiff', '.bmp', '.gif', ".tif"}  # Add or remove extensions as needed
        image_paths = []

        for root, dirs, files in os.walk(self.root_dir):
            for file in files:
                if any(file.lower().endswith(ext) for ext in image_extensions):
                    image_paths.append(os.path.join(root, file))

        return image_paths

    def __init__(self, root_dir, transform=None, label=0):
        self.root_dir = root_dir
        self.transform = transform
        self.images = self.list_images()
        self.label = label

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        img_name = self.images[idx]
        image = Image.open(img_name).convert('RGB')
        if self.transform:
            image = self.transform(image)
        return image, self.label


# Set device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Data directories
data_dir = {
    'category1': 'C:\\Users\\Jingqian Liu\\Downloads\\Compressed\\EECE541_datasets\\original_images',
    'genimage_dir': 'C:\\Users\\Jingqian Liu\\Downloads\\Compressed\\GenImage',
    'landscape_photoreal_dir': 'C:\\Users\\Jingqian Liu\\Downloads\\Compressed\\Landscape_PhotoReal'
}

# Transformations
transform = transforms.Compose([
    transforms.Resize((224, 224)),  # Resize images to 512x512
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])

# Load datasets and split
dataset = datasets.ImageFolder(data_dir["category1"], transform=transform)
combined_dataset = dataset
folder2idx = combined_dataset.class_to_idx
fake_label = folder2idx['DiffusionDB']
train_idx, test_idx = train_test_split(np.arange(len(combined_dataset)), test_size=0.4, random_state=42)
print(
    f"For this run, the fake and real image datasets are {[folder for folder in folder2idx]}. The independent test set"
    f"is {data_dir['genimage_dir']} and {data_dir['landscape_photoreal_dir']}.")
test_idx, val_idx = train_test_split(test_idx, test_size=0.5, random_state=42)

# Dataloaders
batch_size = 36
lr = 0.01 * (50 / 256)
print(f"For this run, the batch size is {batch_size}. The learning rate is {lr}.")
dataloaders = {
    'train': DataLoader(Subset(combined_dataset, train_idx), batch_size=batch_size, shuffle=True),
    'val': DataLoader(Subset(combined_dataset, val_idx), batch_size=batch_size),
    'test': DataLoader(Subset(combined_dataset, test_idx), batch_size=batch_size)
}
genimage_dir = data_dir["genimage_dir"]
genimage_dataset = SingleClassImageFolder(genimage_dir, transform=transform, label=fake_label)
genimage_dataloader = DataLoader(genimage_dataset, batch_size=batch_size)

lp_dir = data_dir["landscape_photoreal_dir"]
lp_dataset = SingleClassImageFolder(lp_dir, transform=transform, label=fake_label)
landscapephotoreal_dataloader = DataLoader(lp_dataset, batch_size=batch_size)

# Initialize model
model = torchvision.models.get_model("resnet50", weights=None, num_classes=2)
model = model.to(device)

# Loss and optimizer
criterion = nn.CrossEntropyLoss()
optimizer = optim.SGD(model.parameters(), lr=lr, momentum=0.9)  # AdamW optimizer


# Metrics calculation function
def calculate_metrics(outputs, labels):
    _, preds = torch.max(outputs, 1)
    return {
        'accuracy': accuracy_score(labels.cpu(), preds.cpu()),
        'recall': recall_score(labels.cpu(), preds.cpu(), zero_division=0.0),
        'precision': precision_score(labels.cpu(), preds.cpu(), zero_division=0.0),
        'f1': f1_score(labels.cpu(), preds.cpu(), zero_division=0.0)
    }


# Training function
def train_model(model, criterion, optimizer, dataloader, device):
    model.train()
    running_loss = 0.0
    for inputs, labels in dataloader:
        inputs, labels = inputs.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        running_loss += loss.item() * inputs.size(0)
    return running_loss / len(dataloader.dataset)


# Validation function
def validate_model(model, criterion, dataloader, device):
    model.eval()
    running_loss = 0.0
    all_metrics = {'accuracy': [], 'recall': [], 'precision': [], 'f1': []}
    with torch.no_grad():
        for inputs, labels in dataloader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            running_loss += loss.item() * inputs.size(0)
            metrics = calculate_metrics(outputs, labels)
            for k, v in metrics.items():
                all_metrics[k].append(v)
    avg_metrics = {k: np.mean(v) for k, v in all_metrics.items()}
    return running_loss / len(dataloader.dataset), avg_metrics


def main():
    num_epochs = 30
    for epoch in tqdm(range(num_epochs), desc="Epochs", total=num_epochs):
        train_loss = train_model(model, criterion, optimizer, dataloaders['train'], device)
        val_loss, val_metrics = validate_model(model, criterion, dataloaders['val'], device)
        test_loss, test_metrics = validate_model(model, criterion, dataloaders['test'], device)
        genimage_test_loss, genimage_test_metrics = validate_model(model, criterion, genimage_dataloader, device)
        lp_test_loss, lp_test_metrics = validate_model(model, criterion, landscapephotoreal_dataloader, device)
        # Log metrics for each epoch
        print(f"\nEpoch {epoch + 1}/{num_epochs}")
        print(f"Training Loss: {train_loss:.4f}")
        print(f"Validation - Loss: {val_loss:.4f}, Metrics: {val_metrics}")
        print(f"Test - Loss: {test_loss:.4f}, Metrics: {test_metrics}")
        print(f"GenImage Test - Loss: {genimage_test_loss:.4f}, Metrics: {genimage_test_metrics}")
        print(f"Landscape PhotoReal Test - Loss: {lp_test_loss:.4f}, Metrics: {lp_test_metrics}")


if __name__ == "__main__":
    main()

r'''
C:\ProgramData\miniconda3\python.exe "C:\Users\Jingqian Liu\PycharmProjects\EECE541DetectFakeImg\python\resnet_baseline.py" 
For this run, the fake and real image datasets are ['DiffusionDB', 'RAISE1000_dataset']. The independent test setis C:\Users\Jingqian Liu\Downloads\Compressed\GenImage and C:\Users\Jingqian Liu\Downloads\Compressed\Landscape_PhotoReal.
For this run, the batch size is 36. The learning rate is 0.001953125.
Epochs:   3%|▎         | 1/30 [14:46<7:08:33, 886.68s/it]
Epoch 1/30
Training Loss: 0.8140
Validation - Loss: 4.3709, Metrics: {'accuracy': 0.41898148148148145, 'recall': 0.2325466306301546, 'precision': 0.40694213194213197, 'f1': 0.2897118472587433}
Test - Loss: 3.8876, Metrics: {'accuracy': 0.4837962962962963, 'recall': 0.2564219102048049, 'precision': 0.4186958874458874, 'f1': 0.312575888704921}
GenImage Test - Loss: 0.4360, Metrics: {'accuracy': 0.7186222403924775, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 0.8771, Metrics: {'accuracy': 0.22590702947845806, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}

Epoch 2/30
Training Loss: 0.5931
Validation - Loss: 0.5512, Metrics: {'accuracy': 0.7569444444444443, 'recall': 0.5874526153988396, 'precision': 0.7989682430858901, 'f1': 0.6749782479314387}
Test - Loss: 0.4774, Metrics: {'accuracy': 0.7708333333333334, 'recall': 0.6504215874281664, 'precision': 0.8290043533464586, 'f1': 0.721018542962134}
GenImage Test - Loss: 0.7106, Metrics: {'accuracy': 0.6998046697556102, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 0.3550, Metrics: {'accuracy': 0.8867630385487528, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Epochs:  10%|█         | 3/30 [43:56<6:34:49, 877.37s/it]
Epoch 3/30
Training Loss: 0.4675
Validation - Loss: 0.5733, Metrics: {'accuracy': 0.7615740740740741, 'recall': 0.7530654975162984, 'precision': 0.7826042378673957, 'f1': 0.7664696653408972}
Test - Loss: 0.4652, Metrics: {'accuracy': 0.7962962962962963, 'recall': 0.755930941621731, 'precision': 0.7789942771366919, 'f1': 0.7650274457110865}
GenImage Test - Loss: 1.0663, Metrics: {'accuracy': 0.542143635868084, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 0.7238, Metrics: {'accuracy': 0.5980725623582767, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}

Epoch 4/30
Training Loss: 0.4984
Validation - Loss: 0.8623, Metrics: {'accuracy': 0.8379629629629629, 'recall': 0.8233885245612934, 'precision': 0.8650035339760572, 'f1': 0.8417434982115215}
Test - Loss: 0.4353, Metrics: {'accuracy': 0.8865740740740741, 'recall': 0.871300251892357, 'precision': 0.8802390473733354, 'f1': 0.8743611476613361}
GenImage Test - Loss: 2.5505, Metrics: {'accuracy': 0.5219065140365222, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 0.5994, Metrics: {'accuracy': 0.7110260770975059, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Epochs:  17%|█▋        | 5/30 [1:13:03<6:04:28, 874.73s/it]
Epoch 5/30
Training Loss: 0.5010
Validation - Loss: 0.3664, Metrics: {'accuracy': 0.8587962962962963, 'recall': 0.9001192595014104, 'precision': 0.8456223308854888, 'f1': 0.8698467930795243}
Test - Loss: 0.3337, Metrics: {'accuracy': 0.8888888888888888, 'recall': 0.9351425438596491, 'precision': 0.8408842947510388, 'f1': 0.8823512521245647}
GenImage Test - Loss: 2.9577, Metrics: {'accuracy': 0.4236281457254474, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 1.5963, Metrics: {'accuracy': 0.3604024943310658, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}

Epoch 6/30
Training Loss: 0.3885
Validation - Loss: 0.5394, Metrics: {'accuracy': 0.7708333333333334, 'recall': 0.9611563631300474, 'precision': 0.6941987807711195, 'f1': 0.8021585334387212}
Test - Loss: 0.5787, Metrics: {'accuracy': 0.7777777777777777, 'recall': 0.972548558897243, 'precision': 0.6794476552771748, 'f1': 0.7960284835872193}
GenImage Test - Loss: 3.4706, Metrics: {'accuracy': 0.23743981102934494, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 2.1226, Metrics: {'accuracy': 0.1354875283446712, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Epochs:  23%|██▎       | 7/30 [1:42:12<5:35:22, 874.90s/it]
Epoch 7/30
Training Loss: 0.3624
Validation - Loss: 0.2908, Metrics: {'accuracy': 0.8796296296296297, 'recall': 0.928741636150103, 'precision': 0.8596649465671206, 'f1': 0.8911681203129064}
Test - Loss: 0.2842, Metrics: {'accuracy': 0.8796296296296297, 'recall': 0.926676302498671, 'precision': 0.8315703474372205, 'f1': 0.8734428257357824}
GenImage Test - Loss: 2.3142, Metrics: {'accuracy': 0.47244935041337327, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 1.1754, Metrics: {'accuracy': 0.3878968253968253, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Epochs:  27%|██▋       | 8/30 [1:56:47<5:20:47, 874.86s/it]
Epoch 8/30
Training Loss: 0.2922
Validation - Loss: 0.2842, Metrics: {'accuracy': 0.8726851851851851, 'recall': 0.9418520637342148, 'precision': 0.8400195714457391, 'f1': 0.8863244122123036}
Test - Loss: 0.2774, Metrics: {'accuracy': 0.8958333333333331, 'recall': 0.9637766290726817, 'precision': 0.8308234974901643, 'f1': 0.8897464288745801}
GenImage Test - Loss: 1.8545, Metrics: {'accuracy': 0.38790088125738165, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 1.1831, Metrics: {'accuracy': 0.3598356009070295, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Epochs:  30%|███       | 9/30 [2:10:49<5:02:36, 864.62s/it]
Epoch 9/30
Training Loss: 0.2885
Validation - Loss: 0.2554, Metrics: {'accuracy': 0.8842592592592592, 'recall': 0.8523569573912823, 'precision': 0.9265419937246563, 'f1': 0.8863469190740006}
Test - Loss: 0.2140, Metrics: {'accuracy': 0.9143518518518517, 'recall': 0.8955289897724108, 'precision': 0.9144439846645729, 'f1': 0.9023256979147455}
GenImage Test - Loss: 2.2471, Metrics: {'accuracy': 0.5132983555918961, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 0.8682, Metrics: {'accuracy': 0.55031179138322, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Epochs:  33%|███▎      | 10/30 [2:24:47<4:45:27, 856.37s/it]
Epoch 10/30
Training Loss: 0.2592
Validation - Loss: 0.5961, Metrics: {'accuracy': 0.8449074074074076, 'recall': 0.7267771977154128, 'precision': 0.9809027777777777, 'f1': 0.8314258841735621}
Test - Loss: 0.4108, Metrics: {'accuracy': 0.8657407407407408, 'recall': 0.720489671147566, 'precision': 0.9956140350877193, 'f1': 0.8315145321587697}
GenImage Test - Loss: 1.0810, Metrics: {'accuracy': 0.7749159625692742, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 0.2910, Metrics: {'accuracy': 0.8799603174603174, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}

Epoch 11/30
Training Loss: 0.3602
Validation - Loss: 0.3087, Metrics: {'accuracy': 0.8819444444444443, 'recall': 0.8452141002484251, 'precision': 0.9203854528254682, 'f1': 0.8795223678509755}
Test - Loss: 0.2608, Metrics: {'accuracy': 0.9120370370370371, 'recall': 0.8917411109845322, 'precision': 0.9196772880268305, 'f1': 0.9042252597006418}
GenImage Test - Loss: 3.8682, Metrics: {'accuracy': 0.5877282638321069, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 0.6742, Metrics: {'accuracy': 0.6884920634920635, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Epochs:  40%|████      | 12/30 [2:53:52<4:19:50, 866.13s/it]
Epoch 12/30
Training Loss: 0.2272
Validation - Loss: 0.3053, Metrics: {'accuracy': 0.8796296296296297, 'recall': 0.9353899268372953, 'precision': 0.8499563034431455, 'f1': 0.8890213647011639}
Test - Loss: 0.2977, Metrics: {'accuracy': 0.8819444444444445, 'recall': 0.9712258075744917, 'precision': 0.8084355446517826, 'f1': 0.8784901578912012}
GenImage Test - Loss: 3.3994, Metrics: {'accuracy': 0.3797356227855001, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 1.6388, Metrics: {'accuracy': 0.3280895691609978, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Epochs:  43%|████▎     | 13/30 [3:07:21<4:00:27, 848.66s/it]
Epoch 13/30
Training Loss: 0.3407
Validation - Loss: 0.3166, Metrics: {'accuracy': 0.9050925925925924, 'recall': 0.8362193912537162, 'precision': 0.976460113960114, 'f1': 0.8986330335805661}
Test - Loss: 0.2419, Metrics: {'accuracy': 0.8935185185185186, 'recall': 0.8110100060757955, 'precision': 0.9584757834757834, 'f1': 0.873235826127622}
GenImage Test - Loss: 2.2944, Metrics: {'accuracy': 0.6804987735077678, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 0.2781, Metrics: {'accuracy': 0.8816609977324265, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Epochs:  47%|████▋     | 14/30 [3:21:03<3:44:13, 840.87s/it]
Epoch 14/30
Training Loss: 0.2494
Validation - Loss: 0.4106, Metrics: {'accuracy': 0.8796296296296297, 'recall': 0.9415278837189592, 'precision': 0.8494729619382443, 'f1': 0.8913017908396276}
Test - Loss: 0.5474, Metrics: {'accuracy': 0.8703703703703703, 'recall': 0.9494693963443964, 'precision': 0.7999412760442173, 'f1': 0.8636145760667481}
GenImage Test - Loss: 5.9033, Metrics: {'accuracy': 0.3593962932679204, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 1.8688, Metrics: {'accuracy': 0.2814625850340136, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}

Epoch 15/30
Training Loss: 0.2723
Validation - Loss: 0.2482, Metrics: {'accuracy': 0.9097222222222222, 'recall': 0.8841936720369215, 'precision': 0.9415868939282253, 'f1': 0.9100324666147946}
Test - Loss: 0.2475, Metrics: {'accuracy': 0.8935185185185186, 'recall': 0.8789249797473483, 'precision': 0.8878084674040557, 'f1': 0.8730561570732567}
GenImage Test - Loss: 4.4242, Metrics: {'accuracy': 0.5143885709094214, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 0.9942, Metrics: {'accuracy': 0.5646258503401361, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Epochs:  53%|█████▎    | 16/30 [3:49:51<3:19:06, 853.30s/it]
Epoch 16/30
Training Loss: 0.1829
Validation - Loss: 0.2656, Metrics: {'accuracy': 0.9027777777777777, 'recall': 0.854071567258066, 'precision': 0.9596483037659508, 'f1': 0.9019476314964434}
Test - Loss: 0.1896, Metrics: {'accuracy': 0.9050925925925927, 'recall': 0.8548076314523683, 'precision': 0.9382375776397516, 'f1': 0.8871125473269411}
GenImage Test - Loss: 2.6168, Metrics: {'accuracy': 0.5660715908058508, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 0.7040, Metrics: {'accuracy': 0.6272675736961452, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Epochs:  57%|█████▋    | 17/30 [4:04:22<3:06:04, 858.79s/it]
Epoch 17/30
Training Loss: 0.2007
Validation - Loss: 0.3116, Metrics: {'accuracy': 0.8912037037037037, 'recall': 0.9530875800612643, 'precision': 0.8593201237390676, 'f1': 0.90156820792802}
Test - Loss: 0.4452, Metrics: {'accuracy': 0.875, 'recall': 0.9799768518518519, 'precision': 0.7979023427552839, 'f1': 0.8726274122403254}
GenImage Test - Loss: 4.9098, Metrics: {'accuracy': 0.3222494776051603, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 1.6611, Metrics: {'accuracy': 0.2878401360544217, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Epochs:  60%|██████    | 18/30 [4:18:56<2:52:40, 863.38s/it]
Epoch 18/30
Training Loss: 0.1271
Validation - Loss: 0.2202, Metrics: {'accuracy': 0.923611111111111, 'recall': 0.8728480731913226, 'precision': 0.9831363167276481, 'f1': 0.9225917962123394}
Test - Loss: 0.2107, Metrics: {'accuracy': 0.9305555555555557, 'recall': 0.8908632851067063, 'precision': 0.9505718954248367, 'f1': 0.9170569190135995}
GenImage Test - Loss: 3.1149, Metrics: {'accuracy': 0.5743390569637504, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 0.4503, Metrics: {'accuracy': 0.8106575963718822, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Epochs:  63%|██████▎   | 19/30 [4:33:35<2:39:08, 868.03s/it]
Epoch 19/30
Training Loss: 0.1573
Validation - Loss: 0.2601, Metrics: {'accuracy': 0.9097222222222222, 'recall': 0.868181873216198, 'precision': 0.9534751214414526, 'f1': 0.9075224900382782}
Test - Loss: 0.2112, Metrics: {'accuracy': 0.898148148148148, 'recall': 0.8506862168046379, 'precision': 0.9238118073316283, 'f1': 0.8761073987343649}
GenImage Test - Loss: 2.2289, Metrics: {'accuracy': 0.5476401380939402, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 0.8017, Metrics: {'accuracy': 0.5935374149659863, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}

Epoch 20/30
Training Loss: 0.1816
Validation - Loss: 0.2873, Metrics: {'accuracy': 0.9027777777777778, 'recall': 0.9537489557226398, 'precision': 0.8753050246144877, 'f1': 0.9110237227243042}
Test - Loss: 0.3506, Metrics: {'accuracy': 0.8796296296296297, 'recall': 0.9811464424951266, 'precision': 0.8026928850884522, 'f1': 0.8763851554030125}
GenImage Test - Loss: 5.0233, Metrics: {'accuracy': 0.3482442990824022, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 1.9995, Metrics: {'accuracy': 0.3425453514739229, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Epochs:  70%|███████   | 21/30 [5:02:47<2:10:47, 871.94s/it]
Epoch 21/30
Training Loss: 0.1802
Validation - Loss: 0.2559, Metrics: {'accuracy': 0.9027777777777777, 'recall': 0.9229043045690645, 'precision': 0.8940818211342507, 'f1': 0.906874219491152}
Test - Loss: 0.2247, Metrics: {'accuracy': 0.9166666666666666, 'recall': 0.9508826517050202, 'precision': 0.8693953723920744, 'f1': 0.9058561753769837}
GenImage Test - Loss: 3.9588, Metrics: {'accuracy': 0.4396179703824839, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 0.9816, Metrics: {'accuracy': 0.5386904761904762, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Epochs:  73%|███████▎  | 22/30 [5:17:24<1:56:26, 873.31s/it]
Epoch 22/30
Training Loss: 0.1903
Validation - Loss: 0.3447, Metrics: {'accuracy': 0.8888888888888888, 'recall': 0.8159222166087154, 'precision': 0.967548076923077, 'f1': 0.8827211358084099}
Test - Loss: 0.2094, Metrics: {'accuracy': 0.9097222222222222, 'recall': 0.8539570200754412, 'precision': 0.9525446861360174, 'f1': 0.8923984891981238}
GenImage Test - Loss: 1.8296, Metrics: {'accuracy': 0.6162782774597982, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 0.8035, Metrics: {'accuracy': 0.6153628117913831, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Epochs:  77%|███████▋  | 23/30 [5:31:57<1:41:54, 873.48s/it]
Epoch 23/30
Training Loss: 0.1339
Validation - Loss: 0.2803, Metrics: {'accuracy': 0.9027777777777777, 'recall': 0.8642345047951455, 'precision': 0.9451964787878101, 'f1': 0.899672780639733}
Test - Loss: 0.1548, Metrics: {'accuracy': 0.9120370370370371, 'recall': 0.875687719931141, 'precision': 0.9295095755693582, 'f1': 0.8910396759229933}
GenImage Test - Loss: 2.4910, Metrics: {'accuracy': 0.5163532297628781, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 0.9586, Metrics: {'accuracy': 0.5902777777777778, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}

Epoch 24/30
Training Loss: 0.2264
Validation - Loss: 0.3186, Metrics: {'accuracy': 0.8819444444444445, 'recall': 0.9680555555555556, 'precision': 0.8381647196225201, 'f1': 0.8970464993777546}
Test - Loss: 0.3216, Metrics: {'accuracy': 0.8958333333333334, 'recall': 0.9947916666666666, 'precision': 0.819515690455504, 'f1': 0.8924789048612415}
GenImage Test - Loss: 5.3875, Metrics: {'accuracy': 0.3364677023712183, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 2.6848, Metrics: {'accuracy': 0.24305555555555555, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Epochs:  83%|████████▎ | 25/30 [6:01:08<1:12:52, 874.46s/it]
Epoch 25/30
Training Loss: 0.1175
Validation - Loss: 0.2541, Metrics: {'accuracy': 0.9166666666666666, 'recall': 0.8751119399288735, 'precision': 0.9620728199675567, 'f1': 0.9148347043083885}
Test - Loss: 0.1678, Metrics: {'accuracy': 0.9236111111111112, 'recall': 0.8802749455709983, 'precision': 0.9464597902097903, 'f1': 0.904440206217167}
GenImage Test - Loss: 2.4977, Metrics: {'accuracy': 0.5714772417552467, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 0.6065, Metrics: {'accuracy': 0.7312925170068028, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Epochs:  87%|████████▋ | 26/30 [6:15:40<58:15, 873.78s/it]  
Epoch 26/30
Training Loss: 0.1011
Validation - Loss: 0.2554, Metrics: {'accuracy': 0.923611111111111, 'recall': 0.8884782361040943, 'precision': 0.9592434612171453, 'f1': 0.9210088806469611}
Test - Loss: 0.1676, Metrics: {'accuracy': 0.9236111111111112, 'recall': 0.8913588421812108, 'precision': 0.9426719238420006, 'f1': 0.9082448344981748}
GenImage Test - Loss: 2.9913, Metrics: {'accuracy': 0.5435745434723358, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 0.5484, Metrics: {'accuracy': 0.7509920634920635, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}

Epoch 27/30
Training Loss: 0.1620
Validation - Loss: 0.6143, Metrics: {'accuracy': 0.8634259259259259, 'recall': 0.8011053655218415, 'precision': 0.9270381836945304, 'f1': 0.8571276529354864}
Test - Loss: 0.4580, Metrics: {'accuracy': 0.8657407407407408, 'recall': 0.7890795486190224, 'precision': 0.9056474044960887, 'f1': 0.8361977817155252}
GenImage Test - Loss: 1.8363, Metrics: {'accuracy': 0.6240347051876078, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 1.5287, Metrics: {'accuracy': 0.4803004535147392, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Epochs:  93%|█████████▎| 28/30 [6:44:47<29:08, 874.06s/it]
Epoch 28/30
Training Loss: 0.0891
Validation - Loss: 0.3052, Metrics: {'accuracy': 0.9074074074074074, 'recall': 0.8660719789152284, 'precision': 0.948259537733222, 'f1': 0.9040816866169386}
Test - Loss: 0.1808, Metrics: {'accuracy': 0.9074074074074073, 'recall': 0.8749976266423635, 'precision': 0.9256039915966386, 'f1': 0.8901703028685759}
GenImage Test - Loss: 2.1798, Metrics: {'accuracy': 0.6152107749613882, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 0.6396, Metrics: {'accuracy': 0.713718820861678, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Epochs:  97%|█████████▋| 29/30 [6:59:23<14:34, 874.77s/it]
Epoch 29/30
Training Loss: 0.0913
Validation - Loss: 0.3837, Metrics: {'accuracy': 0.9074074074074074, 'recall': 0.8877170005602499, 'precision': 0.9301249324347151, 'f1': 0.9065449244797071}
Test - Loss: 0.3424, Metrics: {'accuracy': 0.8842592592592592, 'recall': 0.8556854573301941, 'precision': 0.892475669001783, 'f1': 0.8631631280871176}
GenImage Test - Loss: 3.8856, Metrics: {'accuracy': 0.5143090760425184, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 1.0806, Metrics: {'accuracy': 0.5569727891156463, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}

Epoch 30/30
Training Loss: 0.0993
Validation - Loss: 0.2880, Metrics: {'accuracy': 0.9027777777777777, 'recall': 0.9377645502645503, 'precision': 0.8840190229949395, 'f1': 0.9074166858859204}
Test - Loss: 0.3226, Metrics: {'accuracy': 0.9004629629629628, 'recall': 0.9698821707045392, 'precision': 0.8404894424986015, 'f1': 0.894662162196655}
GenImage Test - Loss: 4.7256, Metrics: {'accuracy': 0.3610089034250931, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Landscape PhotoReal Test - Loss: 1.4544, Metrics: {'accuracy': 0.43976757369614516, 'recall': 0.0, 'precision': 0.0, 'f1': 0.0}
Epochs: 100%|██████████| 30/30 [7:13:58<00:00, 867.96s/it]

Process finished with exit code 0
'''
