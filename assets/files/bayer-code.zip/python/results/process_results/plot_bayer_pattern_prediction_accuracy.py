import json
import matplotlib.pyplot as plt
import pandas, os
from typing import Union
import numpy as np

'''The code below extracts the reference Bayer pattern for each image in the RAISE 1000 dataset and convert it into a dictionary. The keys are image filenames and the values are the reference Bayer pattern.'''
raise_info = pandas.read_csv("../../resources/dataset/RAISE_1k.csv")
img_camera = list(zip(raise_info.File, raise_info.Device))
img_camera = {
    img[0]: img[1] for img in img_camera
}
device_bayer_pattern = {
    'Nikon D40': "BGGR".lower(),
    'Nikon D90': "GBRG".lower(),
    'Nikon D7000': "RGGB".lower()
}
img_patterns = {
    img: device_bayer_pattern[img_camera[img]] for img in img_camera
}
del img_patterns["r0bf7f938t"]


def get_best_pattern_from_result_json(
        result_json_path: Union[str, bytes, os.PathLike],
        metric_name: str
) -> dict[str, str]:
    '''

    :param result_json_path: The path to a JSON file containing image comparison results.
    :param metric_name: a image comparison canoical name.
    :return: extracts a dictionary whose keys are image names and values are the Bayer pattern giving the best image comparison result of the metric.
    '''
    with open(result_json_path, "r") as handle:
        result_json = json.load(handle)
    return {
        img.split(".")[0]: result_json[img]["best_results"][metric_name]["best_pattern"] for img in result_json
    }


def plot_histogram(refs, trues, falses, labels, metric, ax, accuracy):
    '''

    :param refs: Reference Bayer pattern of each image. A list of Bayer patterns.
    :param trues: Correctly predicted Bayer patterns. A list of Bayer patterns.
    :param falses: Falsely predicted Bayer patterns. A list of Bayer patterns.
    :param labels: The four bayer patterns.
    :param metric: The metric using which we are predicting. The canonical metric name which is one of ["PSNR","SSIM","vmaf_v0.6.1","vmaf_4k_v0.6.1", "DeltaE2000"].
    :param ax: Matplotlib axis object for drawing the bar graph.
    :param accuracy: The overall prediction accuracy.
    :return: It draws a picture using matplotlib. No return value.
    '''
    positions = np.arange(len(labels))
    width = 0.35
    rects1 = ax.bar(positions - width / 2, refs, width, label='Reference Bayer Patterns')
    rects2 = ax.bar(positions + width / 2, trues, width, label='Correctly Predicted Bayer Patterns', bottom=None)
    rects3 = ax.bar(positions + width / 2, falses, width, label='Wrongly Predicted Bayer Patterns', bottom=trues)
    ax.set_xlabel('Bayer Patterns')
    ax.set_ylabel('Number of Instances')
    ax.set_title(f'Bayer Pattern Prediction by {metric}\nOverall Prediction Accuracy={accuracy:.2f}')
    ax.set_xticks(positions)
    ax.set_xticklabels(labels)
    ax.legend()

    def autolabel(rects, bottoms=None):
        for i, rect in enumerate(rects):
            height = rect.get_height()
            if bottoms:
                total_height = height + bottoms[i]
            else:
                total_height = height

            if height < 26 and bottoms is not None:
                total_height = total_height + 40

            ax.annotate('{}'.format(height),
                        xy=(rect.get_x() + rect.get_width() / 2, total_height),
                        xytext=(0, -1.5),
                        textcoords="offset points",
                        ha='center', va='bottom')

    autolabel(rects1)
    autolabel(rects2)
    autolabel(rects3, trues)


def compare_bayer_pattern_predictions(
        ref_patterns: dict[str, str],
        predicted_patterns: dict[str, str],
        metric_name: str,
        ax
):
    '''The first two arguments are dictionaries with keys being image filenames and the values being the Bayer pattern. The first argument is reference Bayer patterns. The second is predicted bayer patterns.
    metric_name is the metric used for bayer pattern prediction. ax is the matplotlib axis object used for plotting.
    '''
    patterns = {"rggb": 0, "bggr": 1, "grbg": 2, "gbrg": 3}
    correct_pred = [0, 0, 0, 0]
    wrong_pred = [0, 0, 0, 0]
    total_correct = 0
    for img in predicted_patterns:
        pred_pattern = predicted_patterns[img]
        ref_pattern = ref_patterns[img]
        if pred_pattern == ref_pattern:
            total_correct += 1
            correct_pred[patterns[pred_pattern]] += 1
        else:
            wrong_pred[patterns[pred_pattern]] += 1
    refs = [len([img for img in ref_patterns if ref_patterns[img] == pattern]) for pattern in patterns]
    assert sum(refs) == sum(correct_pred) + sum(wrong_pred)
    plot_histogram(refs, correct_pred, wrong_pred, [pattern for pattern in patterns], metric_name, ax, total_correct / sum(refs))
    print(f"The over all Bayer pattern prediction accuracy is {total_correct / sum(refs)} for using {metric_name} for comparison.")


def analyze_bayer_prediction_and_plot(dataset_names, axs, metric_file_prefix=None):
    '''

    :param dataset_names: a dictionary with dataset nicknames as keys and dataset result canonical names as values. Dataset result canonical names should be the string between results JSONs' prefix and "_results.json". For example, dataset_names = {"real": "raise1000_ea","fake": "diffusionDB1000"}. "real" should always be a key of "dataset_names".
    :param metric_file_prefix: a dictionary with image comparison metric canonical names as keys and results JSONs' prefixes as values. Will look for the image comparison metric rsults from the corresponding result JSON files. The default value of this dictionary is given above. The metric canonical names acceptable are ["PSNR","SSIM","vmaf_v0.6.1","vmaf_4k_v0.6.1", "DeltaE2000"].
    axs are the matplotlib axis used for ploting.
    :return: Plot the bayer pattern prediction bar graphs.
    '''
    if metric_file_prefix is None:
        metric_file_prefix = {
            "PSNR": 'psnr_ssim',
            "SSIM": 'psnr_ssim',
            "vmaf_v0.6.1": "vmaf",
            "vmaf_4k_v0.6.1": "vmaf",
            "DeltaE2000": 'deltae2000'
        }
    assert "real" in dataset_names
    for idx, metric in enumerate(metric_file_prefix):
        pred_patterns = get_best_pattern_from_result_json(
            f"{metric_file_prefix[metric]}_{dataset_names['real']}_results.json",
            metric_name=metric
        )
        compare_bayer_pattern_predictions(ref_patterns=img_patterns, predicted_patterns=pred_patterns, metric_name=metric, ax=axs[idx])
