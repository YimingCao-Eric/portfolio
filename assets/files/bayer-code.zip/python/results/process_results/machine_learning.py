import json
import os
import warnings
from math import sqrt
from typing import Union, Callable

import numpy as np
from sklearn.mixture import GaussianMixture
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import AdaBoostClassifier


def read_comparison_results(
        json_file_path: Union[str, bytes, os.PathLike],
        metric_name: str
) -> np.ndarray:
    '''

    :param json_file_path: the path to a JSON file storing image comparison results. e.g. python/results/deltae2000_raise1000_ea_results.json
    :param metric_name: The metric name for which we want to read the best results of all images recorded in the result JSON file.
    :return: a numpy array recording the best image comparison results of the metric specified by metric_name of all the images recorded in the result JSON file.
    '''
    with open(json_file_path, "r") as handle:
        d = json.load(handle)
        best_results = {filename: d[filename]["best_results"][metric_name] for filename in d if
                        d[filename]["best_results"][metric_name]["best_pattern"] != ""}
        best_evals = np.asarray([best_results[img]["best_result"] for img in best_results])
        return best_evals


def read_comparison_minmaxdiffs(
        json_file_path: Union[str, bytes, os.PathLike],
        metric_name: str
) -> np.ndarray:
    '''

    :param json_file_path: the path to a JSON file storing image comparison results. e.g. python/results/deltae2000_raise1000_ea_results.json
    :param metric_name: The metric name for which we want to read the min-max difference of the four image comparison results of all images recorded in the result JSON file.
    :return: a numpy array recording the min-max difference of the four image comparison results of the metric specified by metric_name of all the images recorded in the result JSON file.
    '''
    with open(json_file_path, "r") as handle:
        d = json.load(handle)
        analysis_results = {filename: d[filename]["analysis_results"][metric_name] for filename in d}
        minmax_diffs = np.asarray([analysis_results[img]["min_max_diff"] for img in analysis_results])
        assert not np.isnan(np.sum(minmax_diffs))
        return minmax_diffs


def read_comparison_std(
        json_file_path: Union[str, bytes, os.PathLike],
        metric_name: str
) -> np.ndarray:
    '''

    :param json_file_path: the path to a JSON file storing image comparison results. e.g. python/results/deltae2000_raise1000_ea_results.json
    :param metric_name: The metric name for which we want to read the standard deviations of the four image comparison results of all images recorded in the result JSON file.
    :return: a numpy array recording the standard deviations of the four image comparison results of the metric specified by metric_name of all the images recorded in the result JSON file.
    '''
    with open(json_file_path, "r") as handle:
        d = json.load(handle)
        analysis_results = {filename: d[filename]["analysis_results"][metric_name] for filename in d}
        variance_values = np.asarray([sqrt(analysis_results[img]["variance"]) for img in analysis_results])
        assert not np.isnan(np.sum(variance_values))
        return variance_values


def split_data(data1, data2, test_size=0.2):
    '''
    Both data1 (real images data) and data2 (fake images data) are one dimensional numpy arrays. This function mixes them and split into train-test subsets by the ration specified by test-size.
    All data1 datapoint are given label 0 and data2 datapoints are given label 1.
    '''
    assert data1.shape[-1] == data2.shape[-1] or data1.ndim == data2.ndim == 1, "data1 and data2 must have the same dimension for each data point."
    labels1 = np.zeros(data1.shape[0], dtype=int)
    labels2 = np.ones(data2.shape[0], dtype=int)
    X = np.concatenate([data1, data2]).reshape(-1, data1.shape[-1] if data1.ndim != 1 else 1) # Make sure the shape of x is (N, D) where N is the number of data points and D is the dimension that is at least 1.
    y = np.concatenate([labels1, labels2])
    return train_test_split(X, y, test_size=test_size, random_state=69)


def hard_range_threshold(
        real_data,
        fake_data,
        percentile_cutoffs  # a two element tuple specifying the lower and upper percentile. e.g. (5, 95)
) -> (float, float, dict, Callable):
    '''
    Calculate the accuracy of detecting fake data points using the percentile of a sequence of real data.
    Real and fake data should be numpy arrays of shape [N] where N is the number of data points.
    Return
    1. The lower threshold of the real data determined by the percentile cut-offs
    2. The upper threshold
    3. a dictionary whose "accuracy" field contains a float number specifying the classification accuracy.
    4. a function that takes a 1D numpy array and return a 1D numpy array encoding real-fake classification. True means fake and False means real in this array.
    percentile_cutoffs should be a two element tuple specifying the lower and upper percentile. e.g. (5, 95).
    The first two arguments should be two 1D numpy arrays.
    '''
    if len(real_data.shape) != 1 or len(fake_data.shape) != 1: # Only accepts 1D array. If a multiple dimension is passed in, it was supposed for machine learning models and we do not handle it in percentile prediction.
        return float("nan"), float("nan"), {'accuracy': float("nan"), 'precision': 0, 'recall': 0, 'f1_score': 0}, None
    lower_threshold = np.percentile(real_data, percentile_cutoffs[0])
    upper_threshold = np.percentile(real_data, percentile_cutoffs[1])
    count = np.sum((fake_data < lower_threshold) | (fake_data > upper_threshold))
    accuracy = count / len(fake_data)
    scores = {
        'accuracy': accuracy,
        'precision': 0,
        'recall': 0,
        'f1_score': 0
    }

    def predict(X_test):
        'a function that takes a 1D numpy array and return a 1D numpy array encoding real-fake classification. True means fake and False means real in this array.'
        if X_test.shape[1] == 1: # If the data array's shape is of (N, 1), platten it.
            x = X_test.flatten()
            return ((x < lower_threshold) | (x > upper_threshold)).astype(dtype="float")
        else:
            raise Exception("This method cannot be used to predict data with more than one dimension.") # This line should not be reached.

    return lower_threshold, upper_threshold, scores, predict


def train_gmm_and_evaluate(X_train, X_test, y_train, y_test):
    gmm = GaussianMixture(n_components=2, random_state=69).fit(X_train)
    probs = gmm.predict_proba(X_test)
    predictions = np.argmax(probs, axis=1)

    train_probs = gmm.predict_proba(X_train)
    train_predictions = np.argmax(train_probs, axis=1)
    mapping = {0: 0, 1: 1} # GMM does not have label in clustering so we need to manually find the label.

    # Update the mapping based on available components in train_predictions
    for component in np.unique(train_predictions):
        true_labels_for_component = y_train[train_predictions == component]
        if true_labels_for_component.size > 0:
            mapping[component] = np.bincount(true_labels_for_component.astype(int)).argmax()
        else:
            # Handle the case where a component is not present in train_predictions
            # by assigning it the opposite label of the one present (for binary classification)
            mapping[component] = (np.bincount(y_train.astype(int)).argmax() + 1) % 2

    mapped_predictions = np.array([mapping[pred] for pred in predictions])
    metrics = {
        "accuracy": accuracy_score(y_test, mapped_predictions),
        "precision": precision_score(y_test, mapped_predictions),
        "recall": recall_score(y_test, mapped_predictions),
        "f1_score": f1_score(y_test, mapped_predictions)
    }

    def pred(X_test):
        gmm.predict_proba(X_test)
        probs = gmm.predict_proba(X_test)
        predictions = np.argmax(probs, axis=1)
        mapped_predictions = np.array([mapping[pred] for pred in predictions])
        return mapped_predictions

    return metrics, pred


def train_logistic_regression_and_evaluate(X_train, X_test, y_train, y_test):
    '''
    This comment is for all the functions whose name is in the format of train_***_and_evaluate.
    All these functions take four arguments. The first two are supposed to be two numpy arrays of shape [N, D], where N is the number of datapoints in
    the training set and the test set. D is the number metrics used for each datapoint. The last two arguments are numpy arrays of shape [N] and each datapoint in the array is either 1 or 0, representing
    the labels of the datapoints given in the first two arguments.
    These functions first return a dictionary containing for keys "accuracy", "precision", "recall" and "f1_score", each mapped to floating point
    representing the corresponding evaluation on the test set.
    The second returned object is a function that takes a single numpy array of shape [N, 1] and return a numpy array of shape [N]. The returned array
    contains the labels predicted by the classifier trained on the training set data.
    '''
    classifier = LogisticRegression(random_state=69, max_iter=200).fit(X_train, y_train)
    y_pred = classifier.predict(X_test)
    scores = {
        'accuracy': accuracy_score(y_test, y_pred),
        'precision': precision_score(y_test, y_pred),
        'recall': recall_score(y_test, y_pred),
        'f1_score': f1_score(y_test, y_pred)
    }

    return scores, classifier.predict


def train_svm_and_evaluate(X_train, X_test, y_train, y_test):
    svm_classifier = SVC(kernel='rbf', random_state=69).fit(X_train, y_train)
    y_pred = svm_classifier.predict(X_test)
    scores = {
        'accuracy': accuracy_score(y_test, y_pred),
        'precision': precision_score(y_test, y_pred),
        'recall': recall_score(y_test, y_pred),
        'f1_score': f1_score(y_test, y_pred)
    }

    return scores, svm_classifier.predict


def train_random_forest_and_evaluate(X_train, X_test, y_train, y_test):
    rf_classifier = RandomForestClassifier(random_state=69).fit(X_train, y_train)
    y_pred = rf_classifier.predict(X_test)

    scores = {
        'accuracy': accuracy_score(y_test, y_pred),
        'precision': precision_score(y_test, y_pred),
        'recall': recall_score(y_test, y_pred),
        'f1_score': f1_score(y_test, y_pred)
    }

    return scores, rf_classifier.predict


def train_knn_and_evaluate(X_train, X_test, y_train, y_test, n_neighbors=3):
    knn_classifier = KNeighborsClassifier(n_neighbors=n_neighbors).fit(X_train, y_train)
    y_pred = knn_classifier.predict(X_test)

    scores = {
        'accuracy': accuracy_score(y_test, y_pred),
        'precision': precision_score(y_test, y_pred),
        'recall': recall_score(y_test, y_pred),
        'f1_score': f1_score(y_test, y_pred)
    }

    return scores, knn_classifier.predict


def train_adaboost_and_evaluate(X_train, X_test, y_train, y_test):
    ab_classifier = AdaBoostClassifier(algorithm="SAMME", random_state=69).fit(X_train, y_train)
    y_pred = ab_classifier.predict(X_test)

    scores = {
        'accuracy': accuracy_score(y_test, y_pred),
        'precision': precision_score(y_test, y_pred),
        'recall': recall_score(y_test, y_pred),
        'f1_score': f1_score(y_test, y_pred)
    }

    return scores, ab_classifier.predict


def train_test_all_models(reals, fakes):
    '''
    This function takes data of real and fake images and tries to train classifers to differentiate them.
    reals and fakes are 1D numpy arrays containing read data sequences from result JSON files.
    This function trains machine learning models (Gaussian Mixture, Log Regression, SVM, Random Forest, KNN, Adaboost) to differentiate real data from
    fake data. It also tries to use percentiles of the real data ([(0, 100), (1, 99), (2, 98), (3, 97), (5, 95), (10, 90)]) to detect fake data by checking if fake data fall out of
    a specific percentile of the real data.
    Return a dictionary whose keys are either the machine learning model name ("Gaussian Mixture") or a percentile classifier name following the format "{percentile}-Percentile Range".
    Each value is a dictionary with two keys "scores" and "classifier". The values mapped by "scores" are dictionaries containing for keys "accuracy", "precision", "recall" and "f1_score", each mapped to floating point
    representing the corresponding evaluation on the test set. The values mapped by "classifier" are predictor functions that takes a single numpy array of shape [N, 1] and return a numpy array of shape [N]. The returned array
    contains the labels predicted by the classifier trained on the training set data.
    '''
    models = {
        "Gaussian Mixture": train_gmm_and_evaluate,
        "Logistic Regression": train_logistic_regression_and_evaluate,
        "Support Vector Machine": train_svm_and_evaluate,
        "Random Forest": train_random_forest_and_evaluate,
        "K-nearest-neighbors": train_knn_and_evaluate,
        "Adaboost": train_adaboost_and_evaluate
    }
    trained_results = {}
    X_train, X_test, y_train, y_test = split_data(reals, fakes)
    for r in [(0, 100), (1, 99), (2, 98), (3, 97), (5, 95), (10, 90)]:
        _, _, hard_range_accuracy, range_predict = hard_range_threshold(reals, fakes, (r[0], r[1]))
        trained_results[f"{r}-Percentile Range"] = {
            "scores": hard_range_accuracy,
            "classifier": range_predict
        }
    for model in models:
        scores, classifier = models[model](X_train, X_test, y_train, y_test)
        trained_results[model] = {
            "scores": scores,
            "classifier": classifier
        }
    return trained_results


metric_file_prefix = {
    "PSNR": 'psnr_ssim',
    "SSIM": 'psnr_ssim',
    "vmaf_v0.6.1": "vmaf",
    "vmaf_4k_v0.6.1": "vmaf",
    "DeltaE2000": 'deltae2000'
}


def read_best_results(dataset_names: dict, all_results_dir: str, metric_file_pref: dict = None,
                      read_func: Callable = read_comparison_results) -> dict:
    '''
    :param dataset_names: a dictionary with dataset nicknames as keys and dataset result canonical names as values. Dataset nicknames should be ['real', 'fake']. Dataset result canonical names should be the string between results JSONs' prefix and "_results.json". For example, dataset_names = {"real": "raise1000_ea","fake": "diffusionDB1000"}. "real" and "fake" should always be the only two keys of "dataset_names".
    :param all_results_dir: the directory of all result JSON files.
    :param metric_file_pref: a dictionary whose keys are Metric canonical names and values are the prefix of the result JSON files containing the results of the metric. The default value is given by metric_file_prefix above. The metric canonical names acceptable are ["PSNR","SSIM","vmaf_v0.6.1","vmaf_4k_v0.6.1", "DeltaE2000"].
    :param read_func: should be one of read_comparison_results, read_comparison_minmaxdiffs, read_comparison_std
    :return: a dictionary with all the results picked out by the read_func from the result JSON file. Something like {"PSNR": {"real": [1.0, 2.0 ...], "fake":[2.3,4.5}}
    '''
    if metric_file_pref is None:
        metric_file_pref = metric_file_prefix
    results_dict = {}
    for metric in metric_file_pref:
        results_dict[metric] = {}
        for dataset_name in dataset_names:
            results_dict[metric][dataset_name] = read_func(
                f"{all_results_dir}/{metric_file_pref[metric]}_{dataset_names[dataset_name]}_results.json",
                metric
            )
    return results_dict


def all_learning_methods_all_metrics(dataset_names: dict, all_results_dir: str, read_func: Callable) -> dict:
    '''
    :param dataset_names: a dictionary with dataset nicknames as keys and dataset result canonical names as values. Dataset nicknames should be ['real', 'fake']. Dataset result canonical names should be the string between results JSONs' prefix and "_results.json". For example, dataset_names = {"real": "raise1000_ea","fake": "diffusionDB1000"}. "real" and "fake" should always be the only two keys of "dataset_names".
    :param all_results_dir: the directory of all result JSON files.
    :param read_func: should be one of read_comparison_results, read_comparison_minmaxdiffs, read_comparison_std
    Returns a dictionary whose keys are canonical metric names and values are the dictionaries returned by train_test_all_models on the datapoints of the metric specified by the key. The metric canonical names acceptable are ["PSNR","SSIM","vmaf_v0.6.1","vmaf_4k_v0.6.1", "DeltaE2000"].
    In addition to individual metrics given in metric_file_prefix, this function tries to combine data from different metrics and train machine learning algorithms.
    The ways data are combined can be shown by the dataframes displayed in the "learn_to_differentiate.ipynb" notebook.
    This function is only used in the train_machine_learning_classifiers function in the "learn_to_differentiate.ipynb" notebook. Please also refer
    to the comment of that function to fully understand what this function is doing.
    '''
    results_dict = read_best_results(dataset_names=dataset_names, all_results_dir=all_results_dir, metric_file_pref=metric_file_prefix,
                                     read_func=read_func) # results_dict should be like { "PSNR" : { 'real' : [1,2,3,4]..., 'fake': [1,2,3]...}}

    all_metrics_dict = {}
    for metric in metric_file_prefix:
        all_metrics_dict[metric] = train_test_all_models(results_dict[metric]['real'], results_dict[metric]['fake'])
    # We want to try to use multiple metrics' results to train machine learning models that can handle multi-dimension arrays.
    # Create ndarrays by zipping single dimension results.
    psnr_ssim_zipped = {
        "real": np.asarray(list(zip(results_dict["PSNR"]['real'], results_dict["SSIM"]['real']))),
        "fake": np.asarray(list(zip(results_dict["PSNR"]['fake'], results_dict["SSIM"]['fake'])))
    }
    all_metrics_dict["PSNR SSIM Combined"] = train_test_all_models(psnr_ssim_zipped['real'], psnr_ssim_zipped['fake']) # The name used to key the results in the all_metrics_dict is xxx xxx Combined. XXX is the canonical names of the metrics being combined. The metric canonical names are ["PSNR","SSIM","vmaf_v0.6.1","vmaf_4k_v0.6.1", "DeltaE2000"].

    psnr_ssim_vmaf061_zipped = {
        "real": np.asarray(list(zip(results_dict["PSNR"]['real'], results_dict["SSIM"]['real'], results_dict["vmaf_v0.6.1"]['real']))),
        'fake': np.asarray(list(zip(results_dict["PSNR"]['fake'], results_dict["SSIM"]['fake'], results_dict["vmaf_v0.6.1"]['fake']))),
    }
    all_metrics_dict["PSNR SSIM VMAF Combined"] = train_test_all_models(psnr_ssim_vmaf061_zipped['real'], psnr_ssim_vmaf061_zipped['fake'])

    psnr_ssim_vmaf061_deltae_zipped = {
        "real": np.asarray(
            list(
                zip(
                    results_dict["PSNR"]['real'],
                    results_dict["SSIM"]['real'],
                    results_dict["vmaf_v0.6.1"]['real'],
                    results_dict["DeltaE2000"]['real']
                )
            )
        ),
        'fake': np.asarray(
            list(
                zip(
                    results_dict["PSNR"]['fake'],
                    results_dict["SSIM"]['fake'],
                    results_dict["vmaf_v0.6.1"]['fake'],
                    results_dict["DeltaE2000"]['fake']
                )
            )
        ),
    }
    all_metrics_dict["PSNR SSIM VMAF Delta-E Combined"] = train_test_all_models(psnr_ssim_vmaf061_deltae_zipped['real'],
                                                                                psnr_ssim_vmaf061_deltae_zipped['fake'])

    all_metrics_combined = {
        "real": np.asarray(
            list(
                zip(
                    results_dict["PSNR"]['real'],
                    results_dict["SSIM"]['real'],
                    results_dict["vmaf_v0.6.1"]['real'],
                    results_dict["vmaf_4k_v0.6.1"]['real'],
                    results_dict["DeltaE2000"]['real']
                )
            )
        ),
        'fake': np.asarray(
            list(
                zip(results_dict["PSNR"]['fake'],
                    results_dict["SSIM"]['fake'],
                    results_dict["vmaf_v0.6.1"]['fake'],
                    results_dict["vmaf_4k_v0.6.1"]['fake'],
                    results_dict["DeltaE2000"]['fake']
                    )
            )
        ),
    }
    all_metrics_dict["All Metrics Combined"] = train_test_all_models(all_metrics_combined['real'], all_metrics_combined['fake']) # Use all the available metrics' results to train classifiers.
    return all_metrics_dict


def extract_evaluation_from_all_metrics_dict_by_type(eval_type: str, all_metrics_dict: dict) -> dict:
    '''

    :param eval_type: one of "accuracy", "recall", "precision", "f1_score"
    :param all_metrics_dict: The returned dictionary from a call to function all_learning_methods_all_metrics
    :return: extract the type of evaluation specified by eval_type to a dictionary like {"PSNR": {"Adaboost":0.97}}
    '''
    extracted_dict = {}
    for metric in all_metrics_dict:
        extracted_dict[metric] = {}
        for model in all_metrics_dict[metric]:
            extracted_dict[metric][model] = all_metrics_dict[metric][model]['scores'][eval_type]
    return extracted_dict


def extract_classifiers_from_all_metrics_dict_by_type(all_metrics_dict: dict) -> dict:
    '''
    :param all_metrics_dict: The returned dictionary from a call to function all_learning_methods_all_metrics
    :return: extracts the function to predict using trained classifiers to a dictionary like {"PSNR": {"Adaboost": Callable[[np.ndarray],np.ndarray]}}
    This Callable variable is the pre-trained classifier (can be either machine learning or percentile classifier.)
    '''
    extracted_dict = {}
    for metric in all_metrics_dict:
        extracted_dict[metric] = {}
        for model in all_metrics_dict[metric]:
            extracted_dict[metric][model] = all_metrics_dict[metric][model]['classifier']
    return extracted_dict


def test_trained_models(all_results: dict, dataset_names: dict, dataset_nickname: str, label: float, read_func: Callable) -> dict:
    '''

    :param all_results: The returned dictionary from a call to function all_learning_methods_all_metrics
    :param dataset_names: a dictionary with dataset nicknames as keys and dataset result canonical names as values. Dataset nicknames should be ['real', 'fake']. Dataset result canonical names should be the string between results JSONs' prefix and "_results.json". For example, dataset_names = {"real": "raise1000_ea","fake": "diffusionDB1000"}. "real" and "fake" should always be the only two keys of "dataset_names".

    :param dataset_nickname: The nickname of the dataset for which we want to test the accuracy of the trained classifiers. For example, "fake".
    :param label: The label of the dataset. If we are testing fake images, this should be 1.
    :param read_func: should be one of read_comparison_results, read_comparison_minmaxdiffs, read_comparison_std, depending on which type of data do we want to use for real-fake differentiation.
    :return: a dictionary whose keys are metric canonical names and values are maps whose keys are the classifier names the values are prediction accuracies. The metric canonical names acceptable are ["PSNR","SSIM","vmaf_v0.6.1","vmaf_4k_v0.6.1", "DeltaE2000"].
    '''
    trained_models = extract_classifiers_from_all_metrics_dict_by_type(all_results)
    results_dict = read_best_results(dataset_names=dataset_names, all_results_dir=".", read_func=read_func)
    accuracies = {}
    for metric in metric_file_prefix:
        accuracies[metric] = {}
        array = np.asarray(results_dict[metric][dataset_nickname]).reshape(-1, 1) # Reshape (N) arrays to (N, 1).
        labels = np.ones(array.shape[0]) * label
        for ml_model in all_results[metric]:
            ml_classifier = trained_models[metric][ml_model]
            predictions = ml_classifier(array) # Call the trained classifier to do prediction.
            accuracy = accuracy_score(labels, predictions)
            accuracies[metric][ml_model] = accuracy
    # The combined metrics should match the ones used in the all_learning_methods_all_metrics function. The order of zipping matters since we want
    # to match the dimensions to specific metrics' results.
    combined_metrics = {
        "PSNR SSIM Combined": np.asarray(list(zip(results_dict["PSNR"][dataset_nickname], results_dict["SSIM"][dataset_nickname]))),
        "PSNR SSIM VMAF Combined": np.asarray(
            list(zip(results_dict["PSNR"][dataset_nickname], results_dict["SSIM"][dataset_nickname], results_dict['vmaf_v0.6.1'][dataset_nickname]))),
        "PSNR SSIM VMAF Delta-E Combined": np.asarray(
            list(zip(results_dict["PSNR"][dataset_nickname], results_dict["SSIM"][dataset_nickname], results_dict['vmaf_v0.6.1'][dataset_nickname],
                     results_dict['DeltaE2000'][dataset_nickname]))),
        "All Metrics Combined": np.asarray(
            list(zip(results_dict["PSNR"][dataset_nickname], results_dict["SSIM"][dataset_nickname], results_dict['vmaf_v0.6.1'][dataset_nickname],
                     results_dict['vmaf_4k_v0.6.1'][dataset_nickname],
                     results_dict['DeltaE2000'][dataset_nickname])))
    }
    for combined_metric in combined_metrics:
        accuracies[combined_metric] = {}
        for ml_model in all_results[combined_metric]:
            if trained_models[combined_metric][ml_model] is None: # Handle the case of percentile predictors where the returned classifier function is None. They do not do multidimension predictions.
                accuracies[combined_metric][ml_model] = float("nan")
            else:
                ml_classifier = trained_models[combined_metric][ml_model]
                x = combined_metrics[combined_metric]
                y = np.ones(x.shape[0]) * label
                predictions = ml_classifier(x)
                accuracy = accuracy_score(y, predictions)
                accuracies[combined_metric][ml_model] = accuracy
    return accuracies


def test_trained_models_on_genimage(all_results: dict, read_func: Callable, genimage_subset: str = "all_genimage_images"):
    'Deprecated. Use test_trained_models instead.'
    trained_models = extract_classifiers_from_all_metrics_dict_by_type(all_results)
    genimage_models = ["ADM", "BigGAN", "glide", "Midjourney", "stable_diffusion_v_1_5", "VQDM", 'wukong']
    genimage_dataset_names = {
        genmodel: f"genimage_{genmodel}" for genmodel in genimage_models
    }
    genimage_best_results = read_best_results(dataset_names=genimage_dataset_names, all_results_dir=".", read_func=read_func)
    reversed_genimage_best_results = {
        genimage_model: {metric: genimage_best_results[metric][genimage_model] for metric in genimage_best_results}
        for genimage_model in genimage_models
    }
    reversed_genimage_best_results["all_genimage_images"] = {
        metric: np.concatenate([
            reversed_genimage_best_results[genimage_model][metric] for genimage_model in genimage_models
        ]) for metric in metric_file_prefix
    }
    accuracies = {}
    target_subset = reversed_genimage_best_results[genimage_subset]
    for metric in metric_file_prefix:
        accuracies[metric] = {}
        for ml_model in all_results[metric]:
            ml_classifier = trained_models[metric][ml_model]
            x = target_subset[metric].reshape(-1, 1)
            y = np.ones(x.shape[0])
            predictions = ml_classifier(x)
            accuracy = accuracy_score(y, predictions)
            accuracies[metric][ml_model] = accuracy
    combined_metrics = {
        "PSNR SSIM Combined": np.asarray(list(zip(target_subset["PSNR"], target_subset["SSIM"]))),
        "PSNR SSIM VMAF Combined": np.asarray(list(zip(target_subset["PSNR"], target_subset["SSIM"], target_subset['vmaf_v0.6.1']))),
        "PSNR SSIM VMAF Delta-E Combined": np.asarray(
            list(zip(target_subset["PSNR"], target_subset["SSIM"], target_subset['vmaf_v0.6.1'], target_subset['DeltaE2000']))),
        "All Metrics Combined": np.asarray(
            list(zip(target_subset["PSNR"], target_subset["SSIM"], target_subset['vmaf_v0.6.1'], target_subset['vmaf_4k_v0.6.1'],
                     target_subset['DeltaE2000'])))
    }
    for combined_metric in combined_metrics:
        accuracies[combined_metric] = {}
        for ml_model in all_results[combined_metric]:
            if trained_models[combined_metric][ml_model] is None:
                accuracies[combined_metric][ml_model] = float("nan")
            else:
                ml_classifier = trained_models[combined_metric][ml_model]
                x = combined_metrics[combined_metric]
                y = np.ones(x.shape[0])
                predictions = ml_classifier(x)
                accuracy = accuracy_score(y, predictions)
                accuracies[combined_metric][ml_model] = accuracy
    return accuracies


def dataframe_to_latex(df, columns, decimal_places=2):
    'Given a dataframe, convert it to a Latex table. Only include columns included in the columns argument.'
    df_selected = df.loc[:, columns]
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=FutureWarning)
        # Format the DataFrame for float precision, affecting only float columns
        formatted_df = df_selected.applymap(lambda x: f"{x:.{decimal_places}f}" if isinstance(x, float) else x)

    # Start the LaTeX table format
    latex_str = "\\begin{table}[H]\n\\centering\n"

    # Add the tabular environment start
    latex_str += "\\begin{tabular}{" + " l | " + " | ".join(['l'] * len(columns)) + " }\n\\hline\n"

    # Add the row names (index) and column headers
    latex_str += ' & '.join([''] + columns) + " \\\\\n\\hline\n"  # Add an empty space for the index column header

    # Add the data rows including the index
    for index, row in formatted_df.iterrows():
        latex_str += index + ' & ' + ' & '.join(row.astype(str)) + " \\\\\n\\hline\n"

    # Close the tabular environment and the table
    latex_str += "\\hline\n\\end{tabular}\n"
    latex_str += "\\end{table}"

    return latex_str


if __name__ == '__main__':
    dataset_names = {
        "real": "raise1000",
        "fake": "diffusionDB1000"
    }
    print(extract_evaluation_from_all_metrics_dict_by_type("accuracy", all_learning_methods_all_metrics(dataset_names, "..")))
