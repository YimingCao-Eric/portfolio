import textwrap
from typing import Callable

import numpy as np

from python.results.process_results.machine_learning import read_comparison_results, read_comparison_std


def plot_histogram(
        ax, # Matplotlib axis objects.
        data_type, # One of "Best", "Minimum-maximum Differences" and "Standard Deviation". Used as a label.
        data1, # numpy 1D array
        data1_name, # the label of data 1
        data2=None,
        data2_name=None,
        data3=None,
        data3_name=None,
        data4=None, # reserved for genimage data sequences.
        data4_name=None,
        data5=None,
        data5_name=None,
        percentile_range=None,
        plot_range_percentile=98, # cap the range of the x axis to the percentile of all the data points combined.
):
    '''
    Plot the distributions of given data sequences on the ax (a matplotlib axis object). Must give at least one data sequence and its name for labeling
    purpose. Please note that data4 is reserved to be used for GenImage data points as we expect it will have more datapoints. We plot it on a separate
    y axis so the scale will not be distorted.
    '''
    if data1.ndim != 1:
        raise ValueError("Input data must be a 1D numpy array.")
    if data2 is not None and data2.ndim != 1:
        raise ValueError("Input data must be a 1D numpy array.")
    if data3 is not None and data3.ndim != 1:
        raise ValueError("Input data must be a 1D numpy array.")
    if data4 is not None and data4.ndim != 1:
        raise ValueError("Input data must be a 1D numpy array.")
    if data5 is not None and data5.ndim != 1:
        raise ValueError("Input data must be a 1D numpy array.")
    all_data = data1.tolist()
    datasets = [data2, data3, data4, data5]
    for data in datasets:
        if data is not None:
            all_data.extend(data.tolist())

    bottom = min(all_data)
    top = np.percentile(np.asarray(all_data), plot_range_percentile)
    num_bins = 40
    bin_width = (top - bottom) / num_bins
    bin_edges = np.arange(bottom, top + bin_width, bin_width)
    bins = bin_edges
    alpha = 0.5
    if data4 is not None:
        ax2 = ax.twinx()
        ax, ax2 = ax2, ax
        ax2.hist(data4, bins=bins, color='yellow', alpha=alpha,
                 label=textwrap.fill(f"{data4_name}, mean={np.mean(data4):.4f}, min={np.min(data4):.4f}, max={np.max(data4):.4f}", width=75))
        ax2.set_ylabel('Frequency for GenImage')
    ax.hist(data1, bins=bins, color='blue', alpha=alpha,
            label=textwrap.fill(f"{data1_name}, mean={np.mean(data1):.4f}, min={np.min(data1):.4f}, max={np.max(data1):.4f}", width=75))

    if data2 is not None:
        ax.hist(data2, bins=bins, color='red', alpha=alpha,
                label=textwrap.fill(f"{data2_name}, mean={np.mean(data2):.4f}, min={np.min(data2):.4f}, max={np.max(data2):.4f}", width=75))
    if data3 is not None:
        ax.hist(data3, bins=bins, color='green', alpha=alpha,
                label=textwrap.fill(f"{data3_name}, mean={np.mean(data3):.4f}, min={np.min(data3):.4f}, max={np.max(data3):.4f}", width=75))
    if data5 is not None:
        ax.hist(data5, bins=bins, color='orange', alpha=alpha,
                label=textwrap.fill(f"{data5_name}, mean={np.mean(data5):.4f}, min={np.min(data5):.4f}, max={np.max(data5):.4f}", width=75))


    if percentile_range is not None:
        lower_percentile_val_data1 = np.percentile(data1, percentile_range[0])
        upper_percentile_val_data1 = np.percentile(data1, percentile_range[1])
        ax.axvline(lower_percentile_val_data1, color='blue', linestyle='dashed', linewidth=1)
        ax.axvline(upper_percentile_val_data1, color='blue', linestyle='dashed', linewidth=1)
        if data2 is not None:
            lower_percentile_val_data2 = np.percentile(data2, percentile_range[0])
            upper_percentile_val_data2 = np.percentile(data2, percentile_range[1])
            ax.axvline(lower_percentile_val_data2, color='red', linestyle='dashed', linewidth=1)
            ax.axvline(upper_percentile_val_data2, color='red', linestyle='dashed', linewidth=1)
        if data3 is not None:
            lower_percentile_val_data3 = np.percentile(data3, percentile_range[0])
            upper_percentile_val_data3 = np.percentile(data3, percentile_range[1])
            ax.axvline(lower_percentile_val_data3, color='green', linestyle='dashed', linewidth=1)
            ax.axvline(upper_percentile_val_data3, color='green', linestyle='dashed', linewidth=1)

    ax.grid(axis='y', alpha=0.75)
    ax.set_xlabel(f'{data_type} of {data1_name.split(" ")[-1]} Comparisons')
    ax.set_ylabel('Frequency' if data4 is None else "Frequency for Other Datasets")
    handles, labels = [], []
    for axi in [ax, ax2] if data4 is not None else [ax]:
        for handle, label in zip(*axi.get_legend_handles_labels()):
            handles.append(handle)
            labels.append(label)
    ax.legend(handles, labels, loc='lower center', shadow=True, bbox_to_anchor=(0.5, 1.05), ncol=1)


def process_best_results(
        ax,
        data_type,
        best_results_dict1: np.ndarray,
        best_result1_name: str,
        best_results_dict2: np.ndarray | None = None,
        best_result2_name: str | None = None,
        best_results_dict3: np.ndarray | None = None,
        best_result3_name: str | None = None,
        best_results_dict4: np.ndarray | None = None,
        best_result4_name: str | None = None,
        best_results_dict5: np.ndarray | None = None,
        best_result5_name: str | None = None,
        plot_range_percentile=98,
) -> (dict, dict):
    # This function is simply a wrapper of the plot histogram function.
    # See the comments of the plot_histogram function for more details.
    plot_histogram(
        ax,
        data_type,
        best_results_dict1,
        best_result1_name,
        best_results_dict2,
        best_result2_name,
        best_results_dict3,
        best_result3_name,
        best_results_dict4,
        best_result4_name,
        best_results_dict5,
        best_result5_name,
        plot_range_percentile=plot_range_percentile
    )


def analyze_image_comparison_distribution_and_plot(
        dataset_names,
        display_dataset_names,
        axs,
        read_func: Callable = read_comparison_results,
        metric_file_prefix=None,
        plot_range_percentile=98,
):
    '''
    :param dataset_names: a dictionary with dataset nicknames as keys and dataset result canonical names as values. Dataset nicknames should be one of ['real', 'fake', 'fake2', 'fake3', 'fake4']. Dataset result canonical names should be the string between results JSONs' prefix and "_results.json". For example, dataset_names = {"real": "raise1000_ea","fake": "diffusionDB1000"}. "real" should always be a key of "dataset_names". "fake3" should only be used for specifying the result JSON file of GenImage dataset.
    :param metric_file_prefix: a dictionary with image comparison metric canonical names as keys and results JSONs' prefixes as values. Will look for the image comparison metric rsults from the corresponding result JSON files. The default value of this dictionary is given above. The metric canonical names acceptable are ["PSNR","SSIM","vmaf_v0.6.1","vmaf_4k_v0.6.1", "DeltaE2000"].
    :param display_ds_names: a dictionary that has the same keys as dataset_names and the proper name of the corresponding dataset for display on the plots. For example, display_ds_names = {'real': "RAISE 1000; EA Demosaicing",'fake': "RAISE 1000; Malvar et al. Demosaicing"}.
    :param axs: Matplotlib axis objects for drawing the distributions. The number os axis object in the list should equal to the number of keys in the metric_file_prefix dictionary so we can plot each metric on one axis.
    :param read_func: should be one of read_comparison_results, read_comparison_minmaxdiffs, read_comparison_std
    :param plot_range_percentile: specify the maximum value on the x-axis. For example, if this parameter is set to 98, then the maximum value on the x-axis is the 98 percentile of all the results read. We do not want to always set it to 100 as sometimes there are really large outlier values that stretches the x-axis so the majority of the bars only lie on the very left of the plot.
    This function does not return anything. It draws image comparison results as distributions using bar graphs.
    '''
    data_type = "Best" if read_func == read_comparison_results else "Standard Deviation" if read_func == read_comparison_std else "Minimum-maximum Differences"
    if metric_file_prefix is None:
        metric_file_prefix = {
            "PSNR": 'psnr_ssim',
            "SSIM": 'psnr_ssim',
            "vmaf_v0.6.1": "vmaf",
            "vmaf_4k_v0.6.1": "vmaf",
            "DeltaE2000": 'deltae2000'
        }
    for idx, metric in enumerate(metric_file_prefix):
        # "real" must always be specified. It must be a key in the dataset_names map.
        real_best_results = read_func(
            json_file_path=f"{metric_file_prefix[metric]}_{dataset_names['real']}_results.json",
            metric_name=metric
        )
        # All the remaining dataset nicknames are optional in the dataset_names map. Only plot them if they are given.
        if "fake" in dataset_names:
            fake_best_results = read_func(
                json_file_path=f"{metric_file_prefix[metric]}_{dataset_names['fake']}_results.json",
                metric_name=metric
            )
            fake_label = f"{display_dataset_names['fake']} {metric}"
        else:
            fake_best_results = None
            fake_label = None

        if "fake2" in dataset_names:
            fake2_best_results = read_func(
                json_file_path=f"{metric_file_prefix[metric]}_{dataset_names['fake2']}_results.json",
                metric_name=metric
            )
            fake2_label = f"{display_dataset_names['fake2']} {metric}"
        else:
            fake2_best_results = None
            fake2_label = None

        if "fake3" in dataset_names:
            fake3_best_results = read_func(
                json_file_path=f"{metric_file_prefix[metric]}_{dataset_names['fake3']}_results.json",
                metric_name=metric
            )
            fake3_label = f"{display_dataset_names['fake3']} {metric}"
        else:
            fake3_best_results = None
            fake3_label = None

        if "fake4" in dataset_names:
            fake4_best_results = read_func(
                json_file_path=f"{metric_file_prefix[metric]}_{dataset_names['fake4']}_results.json",
                metric_name=metric
            )
            fake4_label = f"{display_dataset_names['fake4']} {metric}"
        else:
            fake4_best_results = None
            fake4_label = None

        process_best_results(
            axs[idx],
            data_type,
            real_best_results,
            f"{display_dataset_names['real']} {metric}",
            fake_best_results,
            fake_label,
            fake2_best_results,
            fake2_label,
            fake3_best_results,
            fake3_label,
            fake4_best_results,
            fake4_label,
            plot_range_percentile=plot_range_percentile
        )
