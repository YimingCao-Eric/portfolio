# Python Scripts for the Course Project
## Run the Code and Reproduce Results
In short, the code of this project does four things:
1. Apply resizing and compression operations to images in a dataset and store the modified images. This is handled by code in `compress_imgs.py` and 
`resize_image.py` two scripts.
2. Given a dataset, apply the "redemosaicing" process to each image in the dataset. Store the four images which are the results of redemosaicing the
original image with the four Bayer patterns. This is handled by the scripts in `redemosaic` folder. The primary entry point is the `redemosaic_directory` 
function in `redemosaic/redemosaic_directory.py`.
3. Use PSNR, SSIM, VMAF, VMAF 4K, Delta E to compare the original images in the dataset and the four redemosaiced images. For each comparison metric, calculate the best
score, the min-max difference and the standard deviation of each image's four comparison results. Store all the comparison results in JSON files. The code is in scripts in the `image_similarity_metrics` folder.
The `psnr_ssim_all_imgs_in_directory_pipeline` function in `image_similarity_metrics/psnr_ssim_all_img_directory.py` is the primary entry point for
calculating PSNR and SSIM comparisons. The `vmaf_all_imgs_in_directory_and_compare_results` function in `image_similarity_metrics/vmaf_all_img_directory.py`
is the entry point for calculating VMAF and VMAF 4K comparisons. The `deltae_all_imgs_in_directory_pipeline` function in `image_similarity_metrics/delta_e.py` is the entry point for calculating
Delta E scores.
4. Analyze the result by plotting the results in bar graphs to visualize the distributions. Calculate the Bayer pattern prediction accuracies using the
best comparison results of each image, and try to use percentiles and machine learning models to differentiate real and fake images. These tasks are done
by `results/image_comparison_result_analysis.ipynb`, `results/bayer_pattern_prediction_accuracy.ipynb`, and `results/learn_to_differentiate.ipynb` notebooks.
The code in the scripts in the `python/results/process_results` folder are used to support the functionalities of the three Jupyter Notebooks mentioned above.
These scripts' functions are only supposed to be called from these Jupyter Notebooks. 

If you don't want to care about the detailed implementation and code structure, read the subsections below this document to a quick start of directly using the scripts and notebooks.
For steps 1, 2 and 3, please refer to the "Redemosaic the Images and Compare the Original Images against the Redemosaiced Images" section below. For 
step 4, please refer to the "Generate the Visualization Images and Train Models to Differentiate Fake from Real Images" section below.
Technically speaking there is no need to know what is going on in each Python script and you can just run the code blocks in the Jupyter Notebooks
as described below. Please check out https://docs.jupyter.org/en/latest/running.html if you do not know how to run Jupyter Notebooks.

### Python Dependencies
We use Python 3.10 and 3.11 in the project. We expect most modern Python 3 can work as long as it is compatible with the libraries used in the project.
We used Windows 11 as our operating system.
Please install the packages listed in `python/requirements.txt`. Note that
depending on the hardware, you may want to install GPU-enabled PyTorch versions.
Please refer to the documentation on the official website of PyTorch.

All the scripts and Jupyter Notebooks in this repository assume
that the root directory of the repository (the parent directory of the `python` folder) is added to the Python PATH in your system so
imports can be done properly. We did not use relative path for importing in all the scripts
and Jupyter Notebooks in this repository.

In development, we used PyCharm IDE which automatically sets up the root directory of the code as Python PATH. If you do not use and IDE, you
can check out https://www.javatpoint.com/how-to-set-python-path for how to set up Python PATH properly.

### Redemosaic the Images and Compare the Original Images against the Redemosaiced Images
To apply the redemosaic process and generate the image comparison results of the original images 
and the "redemosaiced" images, follow the instructions and run the code in the `python/results/generate_results.ipynb` notebook.
For the script to run successfully, you need to have
FFMPEG installed in your machine and make sure it can be invoked by command line. For example, this
command `ffmpeg -i distorted.png -i reference.png -lavfi libvmaf=model=version=vmaf_v0.6.1 -f null -`
should run without error for two arbitrary images. 
The link to download the Landscape PhotoReal dataset is given in the `python/results/generate_results.ipynb` notebook.
All the other datasets were sent to us by the support team so the support team should have access to them.
### Generate the Visualization Images and Train Models to Differentiate Fake from Real Images
After you obtain the JSON files containing the image comparison results of different comparison metrics, either
from the submission we provided or from running the code in `python/results/generate_results.ipynb`, you can visualize the
results and try to train models to differentiate fake and real images. To visualize the distribution of the image comparison
results, run the code in `python/results/image_comparison_result_analysis.ipynb`. To visualize the Bayer pattern prediction
accuracies, run the code in `python/results/bayer_pattern_prediction_accuracy.ipynb`. To differentiate real from fake images, either using percentiles 
of the distributions of use machine learning models, run the code in `python/results/learn_to_differentiate.ipynb`.

We also trained a ResNet50 model that tries to directly differentiate real and fake images. The code for this model is in `python/resnet_baseline.py`.
To reproduce the training result,
change the directories mapped by `"category1"`, `"genimage_dir"`,  `"landscape_photoreal_dir"` in the script in the following lines 
```python
data_dir = {
    'category1': 'C:\\Users\\Jingqian\\Downloads\\EECE541_dataset\\original_images', 
    'genimage_dir': 'C:\\Users\\Jingqian Liu\\Downloads\\Compressed\\GenImage',
    'landscape_photoreal_dir': 'C:\\Users\\Jingqian Liu\\Downloads\\Compressed\\Landscape_PhotoReal'
}
```
`"category1"` should point to a directory containing two sub-directories, each of which should contain the original RAISE 1000 dataset and the DiffussionDB 1000 dataset.
That is, 
```
category1-directory
├── dir1(any name)
│   ├── RAISE 1000 image 1
│   └── ...
└── dir2(any name)
    ├── DiffusionDB image 1
    └── ...
```
Then run the script to train the model. The validation and test accuracies should be printed at the end of each epoch.

## Acknowledgement
1.
Our implementation code of the demosaicing algorithm is heavily based on
the [`demosaicing_CFA_Bayer_Malvar2004`](https://github.com/colour-science/colour-demosaicing/blob/develop/colour_demosaicing/bayer/demosaicing/malvar2004.py)
function in the open-source project [colour-demosaicing](https://github.com/colour-science/colour-demosaicing).
We made some changes to the code in this open-source project to make it work on values in integers in the range of [0-255] and to fix compatibility
issues. The demosaicing algorithm is proposed by H.S. Malvar, Li-wei He, and R. Cutler [1].

Similarly, our implementation of the bilinear demosaicing algorithm is heavily based on
the [`demosaicing_CFA_Bayer_bilinear`](https://github.com/colour-science/colour-demosaicing/blob/develop/colour_demosaicing/bayer/demosaicing/bilinear.py)
function in the open-source project [colour-demosaicing](https://github.com/colour-science/colour-demosaicing). 

For both of the two demosaicing algorithms, we made PyTorch-based implementations based on the implementations in the colour-demosaicing library,
so we can use PyTorch for batch processing. The PyTorch adaptation works well in batch processing.

2.   
The scripts `python/image_similarity_metrics/delta_e.py`, and `python/image_similarity_metrics/image_similarity_metrics.py` contain code for PSNR, SSIM,
Delta E calculations. These image comparison metric implementations are based on the implementations 
(https://github.com/scikit-image/scikit-image/blob/v0.23.1/skimage/color/delta_e.py#L152-L283,
https://github.com/scikit-image/scikit-image/blob/v0.23.1/skimage/metrics/_structural_similarity.py#L15-L292,
https://github.com/scikit-image/scikit-image/blob/v0.23.1/skimage/metrics/simple_metrics.py#L112-L167) in scikit-image[3] library. Again the modifications are made, so 
we can use PyTorch for batch processing. The PyTorch adaptation works well in batch processing.

3. 
While writing code of this course project, we used ChatGPT to help us with coding. The usage is primarily on getting example code for libraries' API usage.
The complete chat history of ChatGPT usage in this course project is given in the `chat.html` file. Open it in a browser to see the chat histories.


## References

[1] Malvar, H. S., He, L. W., & Cutler, R. (2004, May). High-quality linear interpolation for demosaicing of Bayer-patterned color images. In 2004
IEEE International Conference on Acoustics, Speech, and Signal Processing (Vol. 3, pp. iii-485). IEEE.

[2] He, K., Zhang, X., Ren, S., & Sun, J. (2016). Deep residual learning for image recognition. In Proceedings of the IEEE conference on computer vision and pattern recognition (pp. 770-778).

[3] Van der Walt, S., Sch"onberger, Johannes L, Nunez-Iglesias, J., Boulogne, Franccois, Warner, J. D., Yager, N., … Yu, T. (2014). scikit-image: image processing in Python. PeerJ, 2, e453.