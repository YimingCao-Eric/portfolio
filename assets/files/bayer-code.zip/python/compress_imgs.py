import os.path

from tqdm import tqdm

from python.utils import get_all_images_in_directory, convert_tiff_to_jpeg_opencv


def compress_imgs(quality: int, target_dir: str, original_img_dir: str) -> None:
    # Compress all the images in original_img_dir, with the target compression quality, and store it into the target_dir.
    img_paths = get_all_images_in_directory(original_img_dir)
    for img_path in tqdm(img_paths, total=len(img_paths)):
        filename, full_path = img_path
        convert_tiff_to_jpeg_opencv(
            full_path,
            os.path.join(target_dir, filename.split(".")[0] + ".jpeg"),
            quality
        )


if __name__ == '__main__':
    target_jpeg_qualities = {
        25: "C:\\Users\\Jingqian\\Downloads\\EECE541_dataset\\jpeg_quality25_raise1000_imgs",
        75: "C:\\Users\\Jingqian\\Downloads\\EECE541_dataset\\jpeg_quality75_raise1000_imgs"
    }
    original_img_dir = 'C:\\Users\\Jingqian\\Downloads\\EECE541_dataset\\original_images\\RAISE1000_dataset'
    for quality in target_jpeg_qualities:
        compress_imgs(quality=quality, target_dir=target_jpeg_qualities[quality], original_img_dir=original_img_dir)
