import unittest

import numpy as np

from python.results.process_results import machine_learning
from python.results.process_results.calculate_cross_bayer_pattern_diff_var import diff_variance_analysis_single_image
from python.results.process_results.machine_learning import read_best_comparison_results, read_best_results, all_learning_methods_all_metrics


class TestMachineLearningDifferentiation(unittest.TestCase):
    def test_read_results(self):
        results = read_best_comparison_results("test_materials/psnr_ssim_foo_results.json", "PSNR")
        self.assertTrue(results.tolist() == [98, 99, 101, 102, 103, 104, 105, 106])
        results = read_best_results(
            {"real": "foo"},
            "test_materials",
            {"PSNR": "psnr_ssim"}
        )
        self.assertTrue("PSNR" in results)
        self.assertTrue("real" in results['PSNR'])
        results = results['PSNR']['real']
        self.assertTrue(results.tolist() == [98, 99, 101, 102, 103, 104, 105, 106])

    def test_calculate_diff_var(self):
        results = diff_variance_analysis_single_image({
            "all_results": {
                "rggb": {
                    "PSNR": 49.90837703670312,
                    "SSIM": 0.9961639762156661
                },
                "bggr": {
                    "PSNR": 50.21181749487201,
                    "SSIM": 0.9963296871895891
                },
                "grbg": {
                    "PSNR": 47.626797855620055,
                    "SSIM": 0.9923846925677965
                },
                "gbrg": {
                    "PSNR": 47.59321148929283,
                    "SSIM": 0.9923115767699761
                }
            },
            "best_results": {
                "PSNR": {
                    "best_result": 50.21181749487201,
                    "best_pattern": "bggr"
                },
                "SSIM": {
                    "best_result": 0.9963296871895891,
                    "best_pattern": "bggr"
                }
            }
        })
        self.assertAlmostEqual(results["analysis_results"]["PSNR"]['min_max_diff'], 2.6186060055791813)
        self.assertAlmostEqual(results["analysis_results"]["PSNR"]['variance'], 1.5123889484311097)
        self.assertAlmostEqual(results["analysis_results"]["SSIM"]['min_max_diff'], 0.00401811041961308)
        self.assertAlmostEqual(results["analysis_results"]["SSIM"]['variance'], 3.8040603960720796e-06)
