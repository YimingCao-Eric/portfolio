import os.path
import unittest
from random import shuffle

import colour_demosaicing
import matlab.engine
import numpy as np
import scipy.io

from python.redemosaic.mht_redemosaic_opencv_implementation import demosaic, mosaic
from python.redemosaic.mht_redemosaic_pytorch_implementation import batch_redemosaic_malvar_numpy_adapter
from python.redemosaic.redemosaic_directory import get_bayer_patterns, redemosaic_directory, get_demosaiced_img_filename
from python.utils import imreadRGB, get_all_images_in_directory, imwriteRGB


class TestBatchMHTDemosaicingImplementation(unittest.TestCase):
    def test_batch_mht_demosaic(self):
        for range in [(0, 7), (0, 20), (0, 256), (230, 256), (250, 256), (253, 256), (0, 2), (254, 256)]:
            for size in {(10, 10), (11, 11), (300, 300), (136, 1051), (21, 42), (43, 21), (24, 63), (60, 20), (61, 81), (87, 68)}:
                low, high = range
                cfa_img = np.random.randint(low=low, high=high, size=(size[0], size[1], 3), dtype="uint8")
                patterns = get_bayer_patterns()
                shuffle(patterns)
                results = batch_redemosaic_malvar_numpy_adapter(cfa_img, patterns)
                self.assertEqual(results.ndim, 4)
                self.assertEqual(results.shape[0], len(patterns))
                self.assertTrue(results.shape[1] == size[0] and results.shape[2] == size[1])
                self.assertEqual(results.shape[3], 3)
                for pattern_idx, pattern in enumerate(patterns):
                    cur_result = results[pattern_idx]
                    ref_result = demosaic(mosaic(cfa_img, pattern), pattern)
                    np.all(np.equal(cur_result, ref_result))

    def test_redemosaic_directory_batch(self):
        target_path = "../../resources/images/sample_diffusiondb_imgs"
        store_path = "../../resources/images/tmp"
        os.mkdir(store_path)
        original_img_count = len(get_all_images_in_directory(store_path))
        ref_path = "../../resources/images/sample_diffusiondb_imgs/redemosaiced_samples"
        redemosaic_directory(
            source_directory_path=target_path,
            dst_directory_path=store_path,
            batch_redemosaic_func=batch_redemosaic_malvar_numpy_adapter
        )
        img_list = get_all_images_in_directory(store_path)
        target_dir_img_count = len(get_all_images_in_directory(target_path))
        self.assertEqual(len(img_list), target_dir_img_count * 4 + original_img_count)
        for img_filename, img_fullpath in img_list:
            self.assertTrue(
                np.all(
                    np.equal(
                        imreadRGB(img_fullpath),
                        imreadRGB(os.path.join(ref_path, img_filename, ))
                    )
                )
            )
            os.remove(img_fullpath)
        os.rmdir(store_path)

    def test_redemosaic_directory(self):
        target_path = "../../resources/images/sample_diffusiondb_imgs"
        store_path = "../../resources/images/tmp"
        os.mkdir(store_path)
        original_img_count = len(get_all_images_in_directory(store_path))
        ref_path = "../../resources/images/sample_diffusiondb_imgs/redemosaiced_samples"
        redemosaic_directory(
            source_directory_path=target_path,
            dst_directory_path=store_path,
            demosaic_func=demosaic
        )
        img_list = get_all_images_in_directory(store_path)
        target_dir_img_count = len(get_all_images_in_directory(target_path))
        self.assertEqual(len(img_list), target_dir_img_count * 4 + original_img_count)
        for img_filename, img_fullpath in img_list:
            self.assertTrue(
                np.all(
                    np.equal(
                        imreadRGB(img_fullpath),
                        imreadRGB(os.path.join(ref_path, img_filename, ))
                    )
                )
            )
            os.remove(img_fullpath)
        os.rmdir(store_path)


class TestMHTDemosaicingImplementation(unittest.TestCase):
    def setUp(self):
        self.eng = matlab.engine.start_matlab()
        self.patterns = ["bggr", "rggb", "grbg", "gbrg"]

    def tearDown(self):
        self.eng.quit()

    def test_matlab_mosaic_implementation(self):
        script_dir = os.path.realpath(__file__).removesuffix(os.path.join(os.path.basename(__file__)))
        matlab_dir = os.path.join(script_dir, "..", "..", "matlab", )
        self.eng.eval(f"addpath('{matlab_dir}');")
        for range in [(0, 7), (0, 20), (0, 256), (230, 256), (250, 256), (253, 256), (0, 2), (254, 256)]:
            for size in {(10, 10), (11, 11), (300, 300), (136, 1051), (21, 42), (43, 21), (24, 63), (60, 20), (61, 81), (87, 68)}:
                for pattern in self.patterns:
                    rand_arr = np.random.randint(range[0], range[1], size=(size[0], size[1], 3), dtype="uint8")
                    ref_result = colour_demosaicing.mosaicing_CFA_Bayer(rand_arr, pattern.upper()).astype("uint8", casting="unsafe")
                    matlab_result = self.eng.mosaic(matlab.uint8(rand_arr.tolist()), pattern, nargout=1)
                    matlab_result = np.asarray(matlab_result)
                    self.assertTrue(np.all(np.equal(matlab_result, ref_result)))

    def test_simple_five_by_five_demosaic(self):
        np_array = np.array(
            [[1, 2, 3, 4, 5],
             [6, 7, 8, 9, 10],
             [11, 12, 13, 14, 15],
             [16, 17, 18, 19, 20],
             [21, 22, 23, 24, 25]],
            dtype=np.uint8
        )
        matlab_array = matlab.uint8(np_array.tolist())
        for pattern in self.patterns:
            result_matlab = self.eng.demosaic(matlab_array, pattern, nargout=1)
            result_matlab = np.asarray(result_matlab)
            result_py = demosaic(np_array, pattern)
            self.assertTrue(np.all(np.equal(result_py, result_matlab)))

    def test_varying_size_demosaic(self):
        for range in [(0, 7), (0, 20), (0, 256), (230, 256), (250, 256), (253, 256), (0, 2), (254, 256)]:
            for size in {(10, 10), (11, 11), (300, 300), (136, 1051), (21, 42), (43, 21), (24, 63), (60, 20), (61, 81), (87, 68)}:
                low, high = range
                cfa_img = np.random.randint(low=low, high=high, size=size, dtype="uint8")
                matlab_array = matlab.uint8(cfa_img.tolist())
                for pattern in self.patterns:
                    result_matlab = np.asarray(self.eng.demosaic(matlab_array, pattern, nargout=1))
                    result_py = demosaic(cfa_img, pattern)
                    self.assertTrue(np.all(np.equal(result_py, result_matlab)))

    def test_varying_size_demosaic_with_mat_files(self):
        def use_matlab_with_mat_files(cfa, pattern):
            scipy.io.savemat("cfa.mat", {"cfa": cfa})
            self.eng.load("cfa.mat", nargout=0)
            self.eng.eval(f'demosaiced = demosaic(cfa,"{pattern}"); save("matlab_demosaiced.mat","demosaiced");', nargout=0)
            return scipy.io.loadmat('matlab_demosaiced.mat')["demosaiced"]

        for range in [(0, 7), (0, 20), (0, 256), (230, 256), (250, 256), (253, 256), (0, 2), (254, 256)]:
            for size in {(10, 10), (11, 11), (300, 300), (136, 1051), (21, 42), (43, 21), (24, 63), (60, 20), (61, 81), (87, 68)}:
                low, high = range
                cfa_img = np.random.randint(low=low, high=high, size=size, dtype="uint8")
                for pattern in self.patterns:
                    result_matlab = use_matlab_with_mat_files(cfa_img, pattern)
                    result_py = demosaic(cfa_img, pattern)
                    self.assertTrue(np.all(np.equal(result_py, result_matlab)))
        os.remove("cfa.mat")
        os.remove("matlab_demosaiced.mat")

    def test_demosaicing_real_img(self):
        script_dir = os.path.realpath(__file__).removesuffix(os.path.join(os.path.basename(__file__)))
        img = imreadRGB(os.path.join(script_dir, "..", "..", "resources", "images", "r000da54ft.tif"))
        for pattern in self.patterns:
            lib_mosaic_result = colour_demosaicing.mosaicing_CFA_Bayer(img, pattern.upper())
            custom_mosaic_result = mosaic(img, pattern)
            self.assertTrue(np.all(np.equal(lib_mosaic_result, custom_mosaic_result)))

            result_matlab = np.asarray(self.eng.demosaic(custom_mosaic_result, pattern, nargout=1))
            result_py = demosaic(custom_mosaic_result, pattern)
            self.assertTrue(np.all(np.equal(result_py, result_matlab)))

    def test_mosaicing_implementation(self):
        for pattern in self.patterns:
            for range in [(0, 7), (0, 20), (0, 256), (230, 256), (250, 256), (253, 256), (0, 2), (254, 256)]:
                for size in {(10, 10), (11, 11), (300, 300), (136, 1051), (21, 42), (43, 21), (24, 63), (60, 20), (61, 81), (87, 68)}:
                    arr = np.random.randint(range[0], range[1], (size[0], size[1], 3))
                    ref_results = colour_demosaicing.mosaicing_CFA_Bayer(arr, pattern.upper())
                    out_results = mosaic(arr, pattern)
                    self.assertTrue(np.all(np.equal(ref_results, out_results)))

    def test_against_precomputed_matlab_demosaic_results(self):
        script_dir = os.path.realpath(__file__).removesuffix(os.path.join(os.path.basename(__file__)))
        img = imreadRGB(
            os.path.join(
                script_dir,
                "..",
                "..",
                "resources",
                "images",
                "sample_diffusiondb_imgs",
                "3ad4a6ac-a23e-4098-9d5a-a44242df5873.png")
        )
        for pattern in self.patterns:
            cfa = colour_demosaicing.mosaicing_CFA_Bayer(img, pattern=pattern.upper())
            redemosaiced = demosaic(cfa, pattern)
            matlab_ref = imreadRGB(
                os.path.join(script_dir, "..", "..", "resources", "images", "sample_diffusiondb_imgs", "redemosaiced_samples",
                             f"matlab_redemosaiced_{pattern}.png"))
            self.assertTrue(np.all(np.equal(matlab_ref, redemosaiced)))

    def test_against_matlab_entire_process(self):
        script_dir = os.path.realpath(__file__).removesuffix(os.path.join(os.path.basename(__file__)))
        matlab_dir = os.path.join(script_dir, "..", "..", "matlab", )
        self.eng.eval(f"addpath('{matlab_dir}');")
        img_path1 = os.path.join(script_dir, "..", "..", "resources", "images", "sample_diffusiondb_imgs", "3ad4a6ac-a23e-4098-9d5a-a44242df5873.png")
        img_path2 = os.path.join(script_dir, "..", "..", "resources", "images", "sample_diffusiondb_imgs", "4a99d1d5-f7da-41de-b92a-e27567d49421.png")
        matlab_tmp_img = os.path.join(script_dir, "..", "..", "resources", "images", "test_tmp.png")
        self.assertTrue("toolbox" in self.eng.eval("which('demosaic');", nargout=1))
        for img_path in [img_path1, img_path2]:
            for pattern in self.patterns:
                self.eng.eval(
                    f"img=imread('{img_path}');cfa=mosaic(img,'{pattern}');result=demosaic(cfa,'{pattern.upper()}');imwrite(result,'{matlab_tmp_img}');",
                    nargout=0)
                matlab_result = imreadRGB(matlab_tmp_img)
                out_demosaic_result = demosaic(mosaic(imreadRGB(img_path), pattern), pattern)
                self.assertTrue(np.all(np.equal(matlab_result, out_demosaic_result)))

        rand_tmp_img = os.path.join(script_dir, "..", "..", "resources", "images", "test_rand_tmp.png")
        for range in [(0, 7), (0, 20), (0, 256), (230, 256), (250, 256), (253, 256), (0, 2), (254, 256)]:
            for size in {(10, 10), (11, 11), (300, 300), (136, 1051), (21, 42), (43, 21), (24, 63), (60, 20), (61, 81), (87, 68)}:
                rand_img = np.random.randint(range[0], range[1], size=(size[0], size[1], 3), dtype="uint8")
                imwriteRGB(rand_tmp_img, rand_img)

                for pattern in self.patterns:
                    self.eng.eval(
                        f"img=imread('{rand_tmp_img}');cfa=mosaic(img,'{pattern}');result=demosaic(cfa,'{pattern.upper()}');imwrite(result,'{matlab_tmp_img}');",
                        nargout=0)
                    matlab_result = imreadRGB(matlab_tmp_img)
                    out_demosaic_result = demosaic(mosaic(imreadRGB(rand_tmp_img), pattern), pattern)
                    self.assertTrue(np.all(np.equal(matlab_result, out_demosaic_result)))

        os.remove(matlab_tmp_img)
        os.remove(rand_tmp_img)

    def test_correctness_precomputed_malvar_demosaiced_imgs(self):
        original_imgs = ["3ad4a6ac-a23e-4098-9d5a-a44242df5873.png", "4a99d1d5-f7da-41de-b92a-e27567d49421.png"]
        script_dir = os.path.realpath(__file__).removesuffix(os.path.join(os.path.basename(__file__)))
        for original_img in original_imgs:
            img = imreadRGB(os.path.join(script_dir, "..", "..", "resources", "images", "sample_diffusiondb_imgs", original_img))
            for pattern in get_bayer_patterns():
                precomputed_demosaiced_img = imreadRGB(os.path.join(script_dir, "..", "..", "resources", "images", "sample_diffusiondb_imgs","redemosaiced_samples",
                                                                    original_img.split(".")[0] + f"_redemosaiced_{pattern}.png"))
                demosaiced_img = demosaic(mosaic(img, pattern), pattern)
                self.assertTrue(np.all(np.equal(precomputed_demosaiced_img, demosaiced_img)))


if __name__ == '__main__':
    unittest.main()
