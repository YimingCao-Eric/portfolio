import unittest

import numpy as np
import torch
from colour_demosaicing import *

from python.redemosaic.batch_redemosaic_bilinear import redemosaic_bilinear
from python.redemosaic.redemosaic_directory import get_bayer_patterns


class TestBatchBilinearDemosaicingImplementation(unittest.TestCase):
    def test_batch_bilinear_demosaic(self):
        for range in [(0, 7), (0, 20), (0, 256), (230, 256), (250, 256), (253, 256), (0, 2), (254, 256)]:
            for size in {(10, 10), (11, 11), (300, 300), (136, 1051), (21, 42), (43, 21), (24, 63), (60, 20), (61, 81), (87, 68)}:
                rgb = np.random.randint(range[0], range[1], (size[0], size[1], 3), dtype=np.uint8)
                custom_result = redemosaic_bilinear(torch.from_numpy(rgb), get_bayer_patterns()).numpy()
                for idx, pattern in enumerate(get_bayer_patterns()):
                    cfa = mosaicing_CFA_Bayer(rgb.astype(np.float32) / 255.0, pattern=pattern.upper())
                    demosaiced = (demosaicing_CFA_Bayer_bilinear(cfa, pattern=pattern.upper()) * 255.0).clip(0, 255).astype(np.uint8)
                    # Because of the difference in the padding strategy, every pixel except the ones on the outermost circle should be the same.
                    self.assertTrue(np.all(np.equal(custom_result[idx][1:-1, 1:-1, :], demosaiced[1:-1, 1:-1, :])))


if __name__ == '__main__':
    unittest.main()
