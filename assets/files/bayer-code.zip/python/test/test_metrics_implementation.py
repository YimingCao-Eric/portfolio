import json
import os.path
import unittest

import numpy as np
import torch
from skimage.metrics import structural_similarity, peak_signal_noise_ratio

from python.image_similarity_metrics.delta_e import delta_e_cie_2000, batch_deltae_adapter, \
    deltae_all_imgs_in_directory_pipeline
from python.image_similarity_metrics.image_similarity_metrics import batch_psnr as psnr_me, PSNR
from python.image_similarity_metrics.image_similarity_metrics import batch_ssim as ssim_me
from python.image_similarity_metrics.psnr_ssim_all_img_directory import psnr_ssim_all_imgs_in_directory_pipeline
from python.image_similarity_metrics.vmaf_all_img_directory import vmaf_all_imgs_in_directory_and_compare_results, vmaf, \
    get_vmaf_versions
from python.redemosaic.redemosaic_directory import get_bayer_patterns
from python.results.process_results.machine_learning import hard_range_threshold
from python.utils import imreadRGB


class TestMachineLearning(unittest.TestCase):
    def test_range_based_predict(self):
        real_data = np.asarray([10, 11, 12, 13, 14, 15, 16, 17, 18, 19])
        fake_data = np.asarray([4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 20])
        min, max, accuracy, pred = hard_range_threshold(real_data, fake_data, (0, 100))
        self.assertAlmostEqual(max, 19)
        self.assertAlmostEqual(min, 10)
        self.assertAlmostEqual(accuracy["accuracy"], 7 / 12)
        test_fake_data = np.asarray([2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 22, 23]).reshape((-1, 1))
        prediction = pred(test_fake_data)
        self.assertAlmostEqual(10 / test_fake_data.shape[0], np.sum(prediction) / test_fake_data.shape[0])
        fake_data = np.asarray([4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 19, 20])
        min, max, accuracy, pred = hard_range_threshold(real_data, fake_data, (10, 90))
        self.assertAlmostEqual(max, 18.1)
        self.assertAlmostEqual(min, 10.9)
        self.assertAlmostEqual(accuracy["accuracy"], 9 / 13)
        test_fake_data = np.asarray([2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 19, 22, 23]).reshape((-1, 1))
        prediction = pred(test_fake_data)
        self.assertAlmostEqual(12 / test_fake_data.shape[0], np.sum(prediction) / test_fake_data.shape[0])


class TestMetrics(unittest.TestCase):
    def test_deltae_pytorch_implementation(self):
        for test_size in {(10, 10), (30, 60), (70, 50), (1024, 2039), (2031, 1008)}:
            target = np.random.randint(low=0, high=255, size=(test_size[0], test_size[1], 3), dtype="uint8")
            pred = np.random.randint(low=0, high=255, size=(1, test_size[0], test_size[1], 3), dtype="uint8")

            sk_result = delta_e_cie_2000(target, pred[0])

            cusomized_ssim_result = batch_deltae_adapter(target=target, preds=pred)
            self.assertAlmostEqual(cusomized_ssim_result[0], np.mean(sk_result), delta=1e-4)

            target = np.random.randint(low=0, high=255, size=(test_size[0], test_size[1], 3), dtype="uint8")
            pred = np.random.randint(low=0, high=255, size=(4, test_size[0], test_size[1], 3), dtype="uint8")
            cusomized_ssim_result = batch_deltae_adapter(preds=pred, target=target)
            for i in range(4):
                cur_pred = pred[i]
                sk_result = delta_e_cie_2000(cur_pred, target)
                self.assertAlmostEqual(cusomized_ssim_result[i], np.mean(sk_result), delta=1e-4)

    def test_ssim_pytorch_implementation(self):
        device = torch.device("cuda" if torch.cuda.is_available()
                              else "mps" if torch.backends.mps.is_available()
        else "cpu")
        for test_size in {(10, 10), (30, 60), (70, 50), (1024, 2039), (2031, 1008)}:
            target = torch.randint(low=0, high=255, size=(test_size[0], test_size[1], 3), dtype=torch.uint8,
                                   device=device)
            pred = torch.randint(low=0, high=255, size=(1, test_size[0], test_size[1], 3), dtype=torch.uint8,
                                 device=device)
            cusomized_ssim_result = ssim_me(pred, target, )[0].item()
            sk_ssim_result = structural_similarity(
                pred[0].cpu().detach().numpy(),
                target.cpu().detach().numpy(),
                channel_axis=2,
                data_range=255
            )
            self.assertAlmostEqual(cusomized_ssim_result, sk_ssim_result, delta=1e-6)

            target = torch.randint(low=0, high=255, size=(test_size[0], test_size[1], 3), dtype=torch.uint8,
                                   device=device)
            pred = torch.randint(low=0, high=255, size=(4, test_size[0], test_size[1], 3), dtype=torch.uint8,
                                 device=device)
            cusomized_ssim_result = ssim_me(pred, target, )
            for i in range(4):
                cur_ssim_result = cusomized_ssim_result[i].item()
                sk_ssim_result = structural_similarity(
                    pred[i].cpu().detach().numpy(),
                    target.cpu().detach().numpy(),
                    channel_axis=2,
                    data_range=255
                )
                self.assertAlmostEqual(cur_ssim_result, sk_ssim_result, places=6)

    def test_psnr_pytorch_implementation(self):
        device = torch.device("cuda" if torch.cuda.is_available()
                              else "mps" if torch.backends.mps.is_available()
        else "cpu")
        for test_size in {(10, 10), (30, 60), (70, 50), (1024, 2039), (2031, 1008)}:
            target = torch.randint(low=0, high=255, size=(test_size[0], test_size[1], 3), dtype=torch.uint8,
                                   device=device)
            pred = torch.randint(low=0, high=255, size=(1, test_size[0], test_size[1], 3), dtype=torch.uint8,
                                 device=device)
            cusomized_psnr_result = psnr_me(pred, target)[0].item()
            sk_psnr_result = peak_signal_noise_ratio(pred[0].cpu().detach().numpy(), target.cpu().detach().numpy(),
                                                     data_range=255)
            self.assertAlmostEqual(cusomized_psnr_result, sk_psnr_result, delta=5e-6)
            target = torch.randint(low=0, high=255, size=(test_size[0], test_size[1], 3), dtype=torch.uint8,
                                   device=device)
            pred = torch.randint(low=0, high=255, size=(4, test_size[0], test_size[1], 3), dtype=torch.uint8,
                                 device=device)
            cusomized_psnr_result = psnr_me(pred, target)
            for i in range(4):
                cur_psnr_result = cusomized_psnr_result[i].item()
                sk_psnr_result = peak_signal_noise_ratio(pred[i].cpu().detach().numpy(), target.cpu().detach().numpy(),
                                                         data_range=255)
                self.assertAlmostEqual(cur_psnr_result, sk_psnr_result, delta=5e-3)

    def test_batch_psnr_ssim(self):
        original_img_dir = "../../resources/images/sample_diffusiondb_imgs"
        redemosaiced_img_dir = "../../resources/images/sample_diffusiondb_imgs/redemosaiced_samples"
        json_dump_filename = "test.json"
        psnr_ssim_all_imgs_in_directory_pipeline(
            directory_path=original_img_dir,
            json_dump_directory_path=original_img_dir,
            json_dump_filename=json_dump_filename,
            redemosaiced_img_dir=redemosaiced_img_dir,
            batch_psnr_ssim=True
        )
        with open(os.path.join(original_img_dir, json_dump_filename), "r") as handle:
            result = json.load(handle)
        self.assertTrue(compare_dicts(expected, result))
        os.remove(os.path.join(original_img_dir, json_dump_filename))

    def test_parallel_psnr_ssim(self):
        original_img_dir = "../../resources/images/sample_diffusiondb_imgs"
        redemosaiced_img_dir = "../../resources/images/sample_diffusiondb_imgs/redemosaiced_samples"
        json_dump_filename = "test.json"
        psnr_ssim_all_imgs_in_directory_pipeline(
            directory_path=original_img_dir,
            json_dump_directory_path=original_img_dir,
            json_dump_filename=json_dump_filename,
            redemosaiced_img_dir=redemosaiced_img_dir,
            batch_psnr_ssim=False
        )
        with open(os.path.join(original_img_dir, json_dump_filename), "r") as handle:
            result_1 = json.load(handle)
        self.assertTrue(compare_dicts(expected, result_1))

        original_img_dir = "../../resources/images/sample_diffusiondb_imgs"
        redemosaiced_img_dir = "../../resources/images/sample_diffusiondb_imgs/redemosaiced_samples"
        json_dump_filename = "test.json"
        psnr_ssim_all_imgs_in_directory_pipeline(
            directory_path=original_img_dir,
            json_dump_directory_path=original_img_dir,
            json_dump_filename=json_dump_filename,
            redemosaiced_img_dir=redemosaiced_img_dir,
            batch_psnr_ssim=True
        )
        with open(os.path.join(original_img_dir, json_dump_filename), "r") as handle:
            result_2 = json.load(handle)
        self.assertTrue(compare_dicts(expected, result_2))
        self.assertTrue(compare_dicts(result_2, result_1))
        os.remove(os.path.join(original_img_dir, json_dump_filename))

    def test_parallel_process_imgs_without_redemosaiced_imgs(self):
        original_img_dir = "../../resources/images/sample_diffusiondb_imgs"
        json_dump_filename = "test.json"
        psnr_ssim_all_imgs_in_directory_pipeline(
            directory_path=original_img_dir,
            json_dump_directory_path=original_img_dir,
            json_dump_filename=json_dump_filename,
            batch_psnr_ssim=False
        )

        with open(os.path.join(original_img_dir, json_dump_filename), "r") as handle:
            result = json.load(handle)
        self.assertTrue(compare_dicts(expected, result))

        original_img_dir = "../../resources/images/sample_diffusiondb_imgs"
        redemosaiced_img_dir = "../../resources/images/sample_diffusiondb_imgs/redemosaiced_samples"
        json_dump_filename = "test.json"
        psnr_ssim_all_imgs_in_directory_pipeline(
            directory_path=original_img_dir,
            json_dump_directory_path=original_img_dir,
            json_dump_filename=json_dump_filename,
            redemosaiced_img_dir=redemosaiced_img_dir,
            batch_psnr_ssim=True
        )
        with open(os.path.join(original_img_dir, json_dump_filename), "r") as handle:
            result_2 = json.load(handle)
        self.assertTrue(compare_dicts(expected, result_2))
        self.assertTrue(compare_dicts(result_2, result))
        os.remove(os.path.join(original_img_dir, json_dump_filename))

    def test_batch_process_deltae(self):
        original_img_dir = "../../resources/images/sample_diffusiondb_imgs"
        redemosaiced_img_dir = "../../resources/images/sample_diffusiondb_imgs/redemosaiced_samples"
        json_dump_filename = ["test1.json", "test2.json"]
        deltae_all_imgs_in_directory_pipeline(
            directory_path=original_img_dir,
            json_dump_directory_path=original_img_dir,
            json_dump_filename=json_dump_filename[0],
            redemosaiced_img_dir=redemosaiced_img_dir,
            batch_deltae=True
        )
        with open(os.path.join(original_img_dir, json_dump_filename[0]), "r") as handle:
            result1 = json.load(handle)
        deltae_all_imgs_in_directory_pipeline(
            directory_path=original_img_dir,
            json_dump_directory_path=original_img_dir,
            json_dump_filename=json_dump_filename[1],
            redemosaiced_img_dir=redemosaiced_img_dir,
            batch_deltae=False
        )
        with open(os.path.join(original_img_dir, json_dump_filename[1]), "r") as handle:
            result2 = json.load(handle)
        self.assertTrue(compare_dicts(dict1=result1, dict2=result2))
        os.remove(os.path.join(original_img_dir, json_dump_filename[0]))
        os.remove(os.path.join(original_img_dir, json_dump_filename[1]))

        original_imgs = ["3ad4a6ac-a23e-4098-9d5a-a44242df5873.png", "4a99d1d5-f7da-41de-b92a-e27567d49421.png"]
        script_dir = os.path.realpath(__file__).removesuffix(os.path.join(os.path.basename(__file__)))
        for original_img in original_imgs:
            img = imreadRGB(os.path.join(script_dir, "..", "..", "resources", "images", "sample_diffusiondb_imgs", original_img))
            lowest_deltae = 100
            lowest_pattern = ""
            for pattern in get_bayer_patterns():
                precomputed_demosaiced_img = imreadRGB(
                    os.path.join(script_dir, "..", "..", "resources", "images", "sample_diffusiondb_imgs", "redemosaiced_samples",
                                 original_img.split(".")[0] + f"_redemosaiced_{pattern}.png")
                )
                deltae_result = delta_e_cie_2000(img, precomputed_demosaiced_img)
                if deltae_result < lowest_deltae:
                    lowest_deltae = deltae_result
                    lowest_pattern = pattern
                self.assertAlmostEqual(deltae_result, result1[original_img]["all_results"][pattern]["DeltaE2000"], delta=1e-5)
            self.assertAlmostEqual(lowest_deltae, result1[original_img]["best_results"]["DeltaE2000"]["best_result"], delta=1e-5)
            self.assertEqual(lowest_pattern, result1[original_img]["best_results"]["DeltaE2000"]["best_pattern"])

    def test_compile_psnr_ssim_results(self):
        original_imgs = ["3ad4a6ac-a23e-4098-9d5a-a44242df5873.png", "4a99d1d5-f7da-41de-b92a-e27567d49421.png"]
        script_dir = os.path.realpath(__file__).removesuffix(os.path.join(os.path.basename(__file__)))
        for original_img in original_imgs:
            img = imreadRGB(
                os.path.join(script_dir, "..", "..", "resources", "images", "sample_diffusiondb_imgs", original_img))

            best_psnr_result = 0
            best_psnr_pattern = ""
            best_ssim_result = 0
            best_ssim_pattern = ""
            for pattern in get_bayer_patterns():
                precomputed_demosaiced_img = imreadRGB(
                    os.path.join(script_dir, "..", "..", "resources", "images", "sample_diffusiondb_imgs",
                                 "redemosaiced_samples",
                                 original_img.split(".")[0] + f"_redemosaiced_{pattern}.png"))
                psnr_result = peak_signal_noise_ratio(precomputed_demosaiced_img, img)
                self.assertAlmostEqual(psnr_result, expected[original_img]['all_results'][pattern]['PSNR'])
                if psnr_result > best_psnr_result:
                    best_psnr_result = psnr_result
                    best_psnr_pattern = pattern

                ssim_result = structural_similarity(precomputed_demosaiced_img, img, channel_axis=2, data_range=255)
                self.assertAlmostEqual(ssim_result, expected[original_img]['all_results'][pattern]['SSIM'])
                if ssim_result > best_ssim_result:
                    best_ssim_pattern = pattern
                    best_ssim_result = ssim_result
            self.assertAlmostEqual(expected[original_img]['best_results']['SSIM']["best_result"], best_ssim_result)
            self.assertTrue(expected[original_img]['best_results']['SSIM']["best_pattern"] == best_ssim_pattern)
            self.assertAlmostEqual(expected[original_img]['best_results']['PSNR']["best_result"], best_psnr_result)
            self.assertTrue(expected[original_img]['best_results']['PSNR']["best_pattern"] == best_psnr_pattern)

    def test_compile_vmaf_results(self):
        original_img_dir = "../../resources/images/sample_diffusiondb_imgs"
        redemosaiced_img_dir = "../../resources/images/sample_diffusiondb_imgs/redemosaiced_samples"
        json_dump_filename = "test1.json"
        vmaf_all_imgs_in_directory_and_compare_results(
            reference_image_directory=original_img_dir,
            redemosaiced_image_directory=redemosaiced_img_dir,
            output_directory=original_img_dir,
            output_json_filename=json_dump_filename
        )
        with open(os.path.join(original_img_dir, json_dump_filename), "r") as handle:
            all_dir_vmaf_result = json.load(handle)
        os.remove(os.path.join(original_img_dir, json_dump_filename))
        original_imgs = ["3ad4a6ac-a23e-4098-9d5a-a44242df5873.png", "4a99d1d5-f7da-41de-b92a-e27567d49421.png"]
        script_dir = os.path.realpath(__file__).removesuffix(os.path.join(os.path.basename(__file__)))
        for original_img in original_imgs:
            for vmaf_version in get_vmaf_versions():
                best_vmaf_score = 0
                best_vmaf_pattern = ''
                for pattern in get_bayer_patterns():
                    img = os.path.join(script_dir, "..", "..", "resources", "images", "sample_diffusiondb_imgs",
                                       original_img)
                    precomputed_demosaiced_img = os.path.join(script_dir, "..", "..", "resources", "images",
                                                              "sample_diffusiondb_imgs",
                                                              "redemosaiced_samples",
                                                              original_img.split(".")[
                                                                  0] + f"_redemosaiced_{pattern}.png")
                    single_vmaf_result = vmaf(ref_img_path=img, target_img_path=precomputed_demosaiced_img,
                                              vmaf_version=vmaf_version)
                    self.assertAlmostEqual(all_dir_vmaf_result[original_img]["all_results"][pattern][vmaf_version],
                                           single_vmaf_result)
                    if single_vmaf_result > best_vmaf_score:
                        best_vmaf_score = single_vmaf_result
                        best_vmaf_pattern = pattern
                self.assertEqual(all_dir_vmaf_result[original_img]["best_results"][vmaf_version]["best_pattern"],
                                 best_vmaf_pattern)
                self.assertAlmostEqual(all_dir_vmaf_result[original_img]["best_results"][vmaf_version]["best_result"],
                                       best_vmaf_score)


expected = {
    "3ad4a6ac-a23e-4098-9d5a-a44242df5873.png": {
        "all_results": {
            "rggb": {
                "PSNR": 37.77054502219923,
                "SSIM": 0.9703220104375158
            },
            "bggr": {
                "PSNR": 37.75655626026543,
                "SSIM": 0.9701760710878856
            },
            "grbg": {
                "PSNR": 37.83755521386841,
                "SSIM": 0.9704982991605776
            },
            "gbrg": {
                "PSNR": 37.82229548482329,
                "SSIM": 0.9704433774695094
            }
        },
        "best_results": {
            "PSNR": {
                "best_result": 37.83755521386841,
                "best_pattern": "grbg"
            },
            "SSIM": {
                "best_result": 0.9704982991605776,
                "best_pattern": "grbg"
            }
        }
    }, "4a99d1d5-f7da-41de-b92a-e27567d49421.png": {
        "all_results": {
            "rggb": {
                "PSNR": 40.75642153383015,
                "SSIM": 0.9843185260547971
            },
            "bggr": {
                "PSNR": 40.70108205243542,
                "SSIM": 0.98408759990768
            },
            "grbg": {
                "PSNR": 40.7613012684577,
                "SSIM": 0.9845237503509039
            },
            "gbrg": {
                "PSNR": 40.65580067569523,
                "SSIM": 0.984213913907564
            }
        },
        "best_results": {
            "PSNR": {
                "best_result": 40.7613012684577,
                "best_pattern": "grbg"
            },
            "SSIM": {
                "best_result": 0.9845237503509039,
                "best_pattern": "grbg"
            }
        }
    }
}


def compare_dicts(dict1, dict2, delta=1e-6):
    """Recursively compare two dictionaries, allowing for a delta in float comparison."""
    if dict1.keys() != dict2.keys():
        return False  # Different sets of keys mean the dicts are not equal

    for key in dict1.keys():
        val1 = dict1[key]
        val2 = dict2[key]

        # If both values are dicts, recurse
        if isinstance(val1, dict) and isinstance(val2, dict):
            if not compare_dicts(val1, val2, delta):
                return False
        # If both values are floats, check if they are approximately equal
        elif isinstance(val1, float) and isinstance(val2, float):
            if not abs(val1 - val2) <= delta:
                return False
        # For other types, check equality directly
        else:
            if val1 != val2:
                return False
    return True


if __name__ == '__main__':
    unittest.main()
