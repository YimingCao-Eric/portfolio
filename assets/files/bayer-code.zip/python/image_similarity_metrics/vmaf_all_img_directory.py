import json
import os
import re
import subprocess
from typing import Union

import tqdm

from python.redemosaic.redemosaic_directory import get_all_images_in_directory, get_bayer_patterns


def vmaf(
        ref_img_path: Union[str, bytes, os.PathLike],
        target_img_path: Union[str, bytes, os.PathLike],
        vmaf_version: str
) -> float:
    '''
    Given a reference image path and a target image path, use VMAF to compare the two images. The vmaf version is one of ["vmaf_v0.6.1", "vmaf_4k_v0.6.1"].
    Return the vmaf comparison results.
    '''
    result = subprocess.run( # Use a subprocess that runs a command.
        f'''ffmpeg -i {target_img_path} -i {ref_img_path} -lavfi libvmaf=model=version={vmaf_version} -f null -'''.split(" "),
        capture_output=True,
        text=True
    )
    if result.returncode != 0:
        raise Exception(f"The call to ffmpeg has a none 0 return code: {result.returncode} -- {result.stderr}")
    output = result.stderr # Catch the output which should be in the stderr channel of the subprocess and use regular expression to parse the output VMAF score from the string.
    pattern = r'VMAF score: ([+-]?([0-9]*[.])?[0-9]+)'
    matches = re.findall(pattern, output)
    if len(matches) != 1:
        raise Exception(f"The output from ffmpeg has zero or more than one VMAF output: {output}")
    return float(matches[0][0])


def get_vmaf_versions():
    return ["vmaf_v0.6.1", "vmaf_4k_v0.6.1"]


def vmaf_all_imgs_in_directory(
        reference_image_directory: Union[str, bytes, os.PathLike],
        redemosaiced_image_directory: Union[str, bytes, os.PathLike],
        output_directory: Union[str, bytes, os.PathLike] = "../results",
        output_json_filename: str = "vmaf_results.json",
):
    '''
    Use VMAF to compare the original images with redemosaiced images. The comparison results are saved in the output directory using the output_json_filename.
    Need to call compile_vmaf_best after this function to finish the process of calculating vmaf scores.
    After this function, each entry in the result JSON file stored looks like this:
    "r005f3e70t.tif":{
      "rggb": {
        "vmaf_v0.6.1": 98.028627,
        "vmaf_4k_v0.6.1": 100.0
      },
      "bggr": {
        "vmaf_v0.6.1": 97.327482,
        "vmaf_4k_v0.6.1": 100.0
      },
      "grbg": {
        "vmaf_v0.6.1": 99.499235,
        "vmaf_4k_v0.6.1": 100.0
      },
      "gbrg": {
        "vmaf_v0.6.1": 98.563833,
        "vmaf_4k_v0.6.1": 100.0
      }
    }
    '''
    assert os.path.exists(reference_image_directory) and os.path.isdir(reference_image_directory), "The given reference image directory is invaid."
    assert os.path.exists(redemosaiced_image_directory) and os.path.isdir(
        redemosaiced_image_directory), "The given redemosaiced image directory is invaid."
    assert os.path.exists(output_directory) and os.path.isdir(output_directory)

    vmaf_versions = get_vmaf_versions()

    ref_img_paths = get_all_images_in_directory(reference_image_directory)
    vmaf_results = {}
    for ref_img_path in tqdm.tqdm(ref_img_paths):
        ref_img_filename, ref_img_filepath = ref_img_path
        split_img_filename = ref_img_filename.split(".")
        assert len(split_img_filename) == 2, "Invalid image file name: " + ref_img_filename
        img_filename_no_postfix = split_img_filename[0] # filename before and after the file type postfix. Used to find the name of redemosaiced images.
        img_filename_postfix = split_img_filename[1]

        img_vmaf_evals = {}
        for pattern in get_bayer_patterns():
            img_vmaf_evals[pattern] = {}
            target_img_filename = f"{img_filename_no_postfix}_redemosaiced_{pattern}.{img_filename_postfix}"
            target_img_filepath = os.path.join(redemosaiced_image_directory, target_img_filename)
            for vmaf_version in vmaf_versions:
                try:
                    vmaf_eval = vmaf(ref_img_filepath, target_img_filepath, vmaf_version)
                    img_vmaf_evals[pattern][vmaf_version] = vmaf_eval
                except Exception as e:
                    img_vmaf_evals[pattern][vmaf_version] = f"error: {e}"
                    print(f"failed to do vmaf evaluation for image {ref_img_filename}, pattern {pattern}: {e}")
        vmaf_results[ref_img_filename] = img_vmaf_evals
        if len(vmaf_results) % 50 == 0:
            with open(os.path.join(output_directory, output_json_filename), "w") as handle:
                json.dump(vmaf_results, handle)

    with open(os.path.join(output_directory, output_json_filename), "w") as handle:
        json.dump(vmaf_results, handle)


def compile_vmaf_best(json_file_path: Union[str, bytes, os.PathLike] = "../results/vmaf_results.json"):
    '''
    Read the vmaf comparison results and for each image, find the best performing Bayer pattern among the four Bayer patterns used for redemosaicing.
    Update the results JSON to include the best results and the patterns giving the best results for each image's results.
    In short, this function adds best results dictionaries that look like this:
    "best_results": {
      "vmaf_v0.6.1": {
        "best_pattern": "grbg",
        "best_result": 99.499235
      },
      "vmaf_4k_v0.6.1": {
        "best_pattern": "rggb",
        "best_result": 100.0
      }
    }
    See the comment of vmaf_all_imgs_in_directory_and_compare_results to know what is the result JSON file after this function is called.
    '''
    with open(json_file_path, "r") as handle:
        vmaf_results = json.load(handle)
    for img_filename in vmaf_results:
        img_vmaf_result = vmaf_results[img_filename]
        img_best_vmafs = {vmaf_version: {"best_pattern": "", "best_result": float("-inf")} for vmaf_version in get_vmaf_versions()}
        for vmaf_version in get_vmaf_versions():
            for pattern in get_bayer_patterns():
                if isinstance(img_vmaf_result[pattern][vmaf_version], str):
                    # This image failed the VMAF evaluation and this place is the error message
                    continue
                if img_vmaf_result[pattern][vmaf_version] > img_best_vmafs[vmaf_version]["best_result"]:
                    img_best_vmafs[vmaf_version]["best_result"] = img_vmaf_result[pattern][vmaf_version]
                    img_best_vmafs[vmaf_version]["best_pattern"] = pattern
        vmaf_results[img_filename] = {
            "all_results": img_vmaf_result,
            "best_results": img_best_vmafs
        }
    with open(json_file_path, "w") as handle:
        json.dump(vmaf_results, handle)


def vmaf_all_imgs_in_directory_and_compare_results(
        reference_image_directory: Union[str, bytes, os.PathLike],
        redemosaiced_image_directory: Union[str, bytes, os.PathLike],
        output_directory: Union[str, bytes, os.PathLike] = "../results",
        output_json_filename: str = "vmaf_results.json",
):
    '''
    Compare the original images with the redemosaiced images using VMAF.
    Save the comparison results in to a JSON file specified by output_directory and output_json_filename.
    The entries in the output JSON should be something like this:
    "r005f3e70t.tif":{
    "all_results": {
      "rggb": {
        "vmaf_v0.6.1": 98.028627,
        "vmaf_4k_v0.6.1": 100.0
      },
      "bggr": {
        "vmaf_v0.6.1": 97.327482,
        "vmaf_4k_v0.6.1": 100.0
      },
      "grbg": {
        "vmaf_v0.6.1": 99.499235,
        "vmaf_4k_v0.6.1": 100.0
      },
      "gbrg": {
        "vmaf_v0.6.1": 98.563833,
        "vmaf_4k_v0.6.1": 100.0
      }
    },
    "best_results": {
      "vmaf_v0.6.1": {
        "best_pattern": "grbg",
        "best_result": 99.499235
      },
      "vmaf_4k_v0.6.1": {
        "best_pattern": "rggb",
        "best_result": 100.0
      }
    }
  }
    '''
    vmaf_all_imgs_in_directory(
        reference_image_directory,
        redemosaiced_image_directory,
        output_directory,
        output_json_filename
    )
    compile_vmaf_best(
        os.path.join(output_directory, output_json_filename)
    )


if __name__ == '__main__':
    genimage_types = ["ADM", "BigGAN", "glide", "Midjourney", "stable_diffusion_v_1_5", "VQDM", 'wukong']
    for genimage_type in tqdm.tqdm(genimage_types, total=len(genimage_types)):
        task = [
            f"E:\\EECE541_dataset\\GenImage\\{genimage_type}",
            f"E:\\EECE541_dataset\\GenImage\\malvar_redemosaiced_{genimage_type}",
            f"vmaf_genimage_{genimage_type}_results.json"
        ]
        ref_img_dir = task[0]
        rede_img_dir = task[1]
        json_dump_filename = task[2]
        vmaf_all_imgs_in_directory_and_compare_results(ref_img_dir, rede_img_dir, output_json_filename=json_dump_filename)
