import multiprocessing
import os
from typing import Union, Callable, Literal

import cv2
import numpy as np
from tqdm import tqdm

from python.redemosaic.batch_redemosaic_bilinear import batch_redemosaic_bilinear_numpy_adapter
from python.redemosaic.mht_redemosaic_opencv_implementation import demosaic, mosaic
from python.redemosaic.mht_redemosaic_pytorch_implementation import batch_redemosaic_malvar_numpy_adapter
from python.redemosaic.opencv_demosaic_algorithms import vng_demosaic, ea_demosaic
from python.utils import imreadRGB, imwriteRGB, get_all_images_in_directory


def get_bayer_patterns() -> list[str]:
    return ["rggb", "bggr", "grbg", "gbrg"]


def split_filename_and_read_img(img_filename: str,
                                img_full_path: str, ) -> (cv2.typing.MatLike, str, str):
    '''
    image_filename is only the filename of an image. img_full_path is the path to the folder storing the image plus the filename.
    This function returns the numpy image read from the location specified by img_full_path, the image filename without file type postfix, and the image filename postfix specifying the image type.
    We split the file name so it is easier to compute the file name of the redemosaiced image.
    '''
    split_img_filename = img_filename.split(".")
    assert len(split_img_filename) == 2, "Invalid image file name: " + img_filename
    img_filename_no_postfix = split_img_filename[0]
    img_filename_postfix = split_img_filename[1]
    return imreadRGB(img_full_path), img_filename_no_postfix, img_filename_postfix


def get_demosaiced_img_filename(img_filename_no_postfix, img_filename_postfix, pattern):
    'Given the parts of the original image name, calculate the name for a redemosaiced version of the image.'
    return f"{img_filename_no_postfix}_redemosaiced_{pattern}.{img_filename_postfix}"


def write_redemosaiced_images(
        img_filename: str,
        img_full_path: str,
        dst_directory_path: Union[str, bytes, os.PathLike],
        demosaic_func,
):
    # Read an image specified by img_full_path; redemosaic it with four Bayer patterns and store
    # the redemosaic results to the folder of dst_directory_path.
    assert os.path.exists(dst_directory_path) and os.path.isdir(dst_directory_path), "The dst_directory_path is invalid."

    try:
        img, img_filename_no_postfix, img_filename_postfix = split_filename_and_read_img(img_filename, img_full_path)
    except Exception as e:
        print(f"Failed to load image {img_filename}: {e}")
        return

    for pattern in get_bayer_patterns():
        cfaimg = mosaic(img, pattern)
        redemosaiced_img = demosaic_func(cfaimg, pattern)
        imwriteRGB(
            os.path.join(dst_directory_path, get_demosaiced_img_filename(img_filename_no_postfix, img_filename_postfix, pattern)),
            redemosaiced_img
        )


def write_redemosaiced_img_wrapper(args):
    '''Wrapper function for multi-processing.
    args should be a tuple containing (img_filename, img_file_fullpath, result_storing_directory_path, demosaic_func)
    '''
    filename, filepath, dst_directory_path, demosaic_func = args
    write_redemosaiced_images(filename, filepath, dst_directory_path, demosaic_func)


def redemosaic_directory(
        source_directory_path: Union[str, bytes, os.PathLike],
        dst_directory_path: Union[str, bytes, os.PathLike],
        demosaic_func: Callable[[np.ndarray, Literal["rggb", "bggr", "grbg", "gbrg"]], np.ndarray] = demosaic,
        batch_redemosaic_func: Callable[[np.ndarray, list[Literal["rggb", "bggr", "grbg", "gbrg"]]], np.ndarray] | None = None,
):
    '''
    Apply the redemosaic process to all the images in the folder of source_directory_path.
    The redemosaic results are stored in the folder of dst_directory_path.
    demosaic_func specifies the demosaic function to be used. By default, it uses the demosaic function in mht_redemosaic_opencv_implementation.py that performs Malvar et al. demosaicing. This function
    can also be the two functions in the `opencv_demosaic_algorithms.py` file.
    batch_redemosaic_func specifies a function that can be used for batch demosaicing. If it is set, the function specified by demosaic_func is ignored.
    batch_redemosaic_func should be set to one of "batch_redemosaic_malvar_numpy_adapter" and "batch_redemosaic_bilinear_numpy_adapter".
    demosaic_func should be set to one of "demosaic", "vng_demosaic", and "ea_demosaic". vng demosaicing and ea demosaicing have no batch implementation. Bilinear demosaicing only has a batch implementation.
    '''
    print(
        f"Doing a directory-level redemosaicing. "
        f"The source directory path is {source_directory_path}, the destination directory path is {dst_directory_path}"
    )

    img_file_infos = get_all_images_in_directory(source_directory_path)
    args = [(img_file_info[0], img_file_info[1], dst_directory_path, demosaic_func) for img_file_info in img_file_infos] # For parallel processing

    if batch_redemosaic_func is None:
        print(f"Using the {demosaic_func.__qualname__} function for demosaicing.")
        num_process = 4
        with multiprocessing.Pool(processes=num_process) as pool:
            result_iterator = pool.imap_unordered(write_redemosaiced_img_wrapper, args)
            for i, result in tqdm(enumerate(result_iterator), total=len(img_file_infos)):
                pass
    else:
        print(f"Using PyTorch-based batch redemosaicing for this execution. The function name is {batch_redemosaic_func.__qualname__}.")
        for arg in tqdm(args):
            img_filename, img_filepath, dst_dir, _ = arg
            assert os.path.exists(dst_directory_path) and os.path.isdir(dst_directory_path), "The dst_directory_path is invalid."
            try:
                img, img_filename_no_postfix, img_filename_postfix = split_filename_and_read_img(img_filename, img_filepath)
            except Exception as e:
                print(f"Failed to load image {img_filename}: {e}")
                continue
            patterns = get_bayer_patterns()
            redemosaic_results = batch_redemosaic_func(img, patterns)
            for pattern_idx, pattern in enumerate(patterns):
                cur_result = redemosaic_results[pattern_idx]
                imwriteRGB(
                    os.path.join(dst_directory_path, get_demosaiced_img_filename(img_filename_no_postfix, img_filename_postfix, pattern)),
                    cur_result
                )


if __name__ == '__main__':
    genimage_types = ["ADM", "BigGAN", "glide", "Midjourney", "stable_diffusion_v_1_5", "VQDM", 'wukong']
    for genimage_type in tqdm(genimage_types):
        args = {
            "source_directory_path": f"E:\\EECE541_dataset\\GenImage\\{genimage_type}",
            "dst_directory_path": f"E:\\EECE541_dataset\\GenImage\\malvar_redemosaiced_{genimage_type}",
            "demosaic_func": None,
            "batch_redemosaic_func": batch_redemosaic_malvar_numpy_adapter
        }
        redemosaic_directory(
            **args
        )
        args = {
            "source_directory_path": f"E:\\EECE541_dataset\\GenImage\\{genimage_type}",
            "dst_directory_path": f"E:\\EECE541_dataset\\GenImage\\bilinear_redemosaiced_{genimage_type}",
            "demosaic_func": None,
            "batch_redemosaic_func": batch_redemosaic_bilinear_numpy_adapter
        }
        redemosaic_directory(
            **args
        )
        args = {
            "source_directory_path": f"E:\\EECE541_dataset\\GenImage\\{genimage_type}",
            "dst_directory_path": f"E:\\EECE541_dataset\\GenImage\\vng_redemosaiced_{genimage_type}",
            "demosaic_func": vng_demosaic,
            "batch_redemosaic_func": None
        }
        redemosaic_directory(
            **args
        )
        args = {
            "source_directory_path": f"E:\\EECE541_dataset\\GenImage\\{genimage_type}",
            "dst_directory_path": f"E:\\EECE541_dataset\\GenImage\\ea_redemosaiced_{genimage_type}",
            "demosaic_func": ea_demosaic,
            "batch_redemosaic_func": None
        }
        redemosaic_directory(
            **args
        )
