rgbImage = imread("eece541/r03ed2669t.TIF");
imshow(rgbImage);
%% full color image to cfa image
sensorAlignment = "rggb";
cfaImage = rgb2cfa(rgbImage, sensorAlignment);
imshow(cfaImage);
%% demosaic cfa image
reconstructImage = demosaic(cfaImage,sensorAlignment);
imshow(reconstructImage)
imwrite(reconstructImage,"eece541/reconstruct_r03ed2669t.TIF")
%% compare with original 
% mean squared error (MSE)
msError = immse(reconstructImage,rgbImage);
% peak signal-to-noise ratio (PSNR)
psnrError = psnr(reconstructImage,rgbImage);
% structural similarity (SSIM)
ssimError = ssim(reconstructImage,rgbImage);
%% Bayer pattern |"gbrg" | "grbg" | "bggr" | "rggb"|
function pattern = bayer_pattern(sensorAlignment)
    if sensorAlignment == "gbrg"
        pattern=[2 3 1 2];
    elseif sensorAlignment == "grbg"
        pattern=[2 1 3 2];
    elseif sensorAlignment == "bggr"
        pattern=[3 2 2 1];
    elseif sensorAlignment == "rggb"
        pattern=[1 2 2 3];
    else

    end
end

% full color image to cfa image
function cfaImage = rgb2cfa(rgbImage, sensorAlignment)
    [rows, columns, channelsNum] = size(rgbImage);
    cfaImage = zeros(rows,columns,"uint8"); 
    
    pattern = bayer_pattern(sensorAlignment);
    % upper left
    cfaImage(1:2:end-1,1:2:end-1) = rgbImage(1:2:end-1,1:2:end-1,pattern(1));
    % upper right
    cfaImage(1:2:end-1,2:2:end) = rgbImage(1:2:end-1,2:2:end,pattern(2));
    % lower left
    cfaImage(2:2:end,1:2:end-1) = rgbImage(2:2:end,1:2:end-1,pattern(3));
    % lower right
    cfaImage(2:2:end,2:2:end) = rgbImage(2:2:end,2:2:end,pattern(4));
end