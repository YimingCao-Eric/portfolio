function cfaImage = rgb2cfa(rgbImage, sensorAlignment)
    [rows, columns, channelsNum] = size(rgbImage);
    cfaImage = zeros(rows,columns,"uint8"); 
    
    pattern = bayer_pattern(sensorAlignment);
    % upper left
    cfaImage(1:2:end,1:2:end) = rgbImage(1:2:end,1:2:end,pattern(1));
    % upper right
    cfaImage(1:2:end,2:2:end) = rgbImage(1:2:end,2:2:end,pattern(2));
    % lower left
    cfaImage(2:2:end,1:2:end) = rgbImage(2:2:end,1:2:end,pattern(3));
    % lower right
    cfaImage(2:2:end,2:2:end) = rgbImage(2:2:end,2:2:end,pattern(4));
end

function pattern = bayer_pattern(sensorAlignment)
    if sensorAlignment == "gbrg"
        pattern=[2 3 1 2];
    elseif sensorAlignment == "grbg"
        pattern=[2 1 3 2];
    elseif sensorAlignment == "bggr"
        pattern=[3 2 2 1];
    elseif sensorAlignment == "rggb"
        pattern=[1 2 2 3];
    else

    end
end